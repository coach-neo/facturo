import { ReactElement } from "react";

export enum Page {
  Dashboard = 'Dashboard',
  Clients = 'Clients',
  Quotes = 'Devis',
  Invoices = 'Factures',
  Settings = 'Mon entreprise',
  Reports = 'Livre des recettes',
}

export interface Client {
  id: string;
  name: string;
  email: string;
  address: string;
  phone?: string;
  notes?: string;
}

export interface LineItem {
  id: string;
  description: string;
  quantity: number | '';
  unitPrice: number | '';
  taxRate: number | ''; // e.g., 0.20 for 20%
}

export enum InvoiceStatus {
  Draft = 'Brouillon',
  Sent = 'Envoyée',
  Paid = 'Payée',
  Overdue = 'En retard',
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  clientId: string;
  issueDate: string;
  dueDate: string;
  lineItems: LineItem[];
  status: InvoiceStatus;
  discount: number; // flat amount
  acompte: number; // flat amount for down payment
  paymentDate?: string;
  paymentMethod?: string;
}

export enum QuoteStatus {
  Draft = 'Brouillon',
  Sent = 'Envoyé',
  Accepted = 'Accepté',
  Declined = 'Refusé',
}

export interface Quote {
  id: string;
  quoteNumber: string;
  clientId: string;
  issueDate: string;
  expiryDate: string;
  lineItems: LineItem[];
  status: QuoteStatus;
  discount: number; // flat amount
  acompte: number; // flat amount for down payment
}

export interface Settings {
  companyName: string;
  companyAddress: string;
  logoUrl: string | null;
  accentColor: string;
  legalInfo: string;
  legalStatus: string;
  isSoleProprietorship: boolean;
  companyOwnerFirstName: string;
  companyOwnerLastName: string;
  bankName: string;
  iban: string;
  bic: string;
  paymentLink: string;
  invoicePrefix: string;
  nextInvoiceNumber: number;
  quotePrefix: string;
  nextQuoteNumber: number;
  defaultTaxRate: number;
  defaultPaymentTerms: string;
  defaultFooterText: string;
}