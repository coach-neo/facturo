import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Remplacez 'VOTRE_NOM_DE_DEPOT' par le nom de votre dépôt GitHub
const repoName = 'VOTRE_NOM_DE_DEPOT'; 

export default defineConfig({
  plugins: [react()],
  base: `/${repoName}/`,
})
