import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, TrendingDown, AlertCircle, Clock, FileText, CheckCircle, FilePlus2, DollarSign } from 'lucide-react';
import { Invoice, Quote, Client, InvoiceStatus, QuoteStatus, Settings } from '../types';
import Card from './ui/Card';
import Button from './ui/Button';

interface DashboardProps {
    invoices: Invoice[];
    quotes: Quote[];
    clients: Client[];
    settings: Settings;
    onEditInvoice: (invoice: Invoice) => void;
    onEditQuote: (quote: Quote) => void;
}

const calculateDocumentTotal = (doc: Invoice | Quote): number => {
    const subtotal = doc.lineItems.reduce((acc, item) => acc + (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0), 0);
    const totalTax = doc.lineItems.reduce((acc, item) => acc + ((Number(item.quantity) || 0) * (Number(item.unitPrice) || 0) * (Number(item.taxRate) || 0)), 0);
    return subtotal + totalTax - (doc.discount || 0);
}

const StatCard: React.FC<{title: string; value: string; trend?: 'up' | 'down' | 'neutral', percentage?: number }> = ({ title, value, trend, percentage }) => (
    <Card>
        <p className="text-sm font-medium text-muted-foreground">{title}</p>
        <div className="flex items-baseline gap-2">
            <p className="text-2xl font-bold text-foreground mt-1">{value}</p>
             {trend && percentage !== undefined && trend !== 'neutral' && (
                <div className={`flex items-center text-xs font-semibold ${trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                    {trend === 'up' ? <TrendingUp size={14} className="mr-1" /> : <TrendingDown size={14} className="mr-1" />}
                    {percentage.toFixed(1)}%
                </div>
            )}
        </div>
        <p className="text-xs text-muted-foreground mt-1">vs mois précédent</p>
    </Card>
);

const Dashboard: React.FC<DashboardProps> = ({ invoices, quotes, clients, settings, onEditInvoice, onEditQuote }) => {
    
    const formatCurrency = (amount: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);

    const stats = useMemo(() => {
        const now = new Date();
        const currentMonth = now.getMonth();
        const currentYear = now.getFullYear();
        const lastMonth = now.getMonth() === 0 ? 11 : now.getMonth() - 1;
        const lastMonthYear = lastMonth === 11 ? currentYear - 1 : currentYear;

        const getRevenueForPeriod = (month: number, year: number) => 
            invoices
                .filter(inv => {
                    const paidDate = inv.paymentDate ? new Date(inv.paymentDate) : null;
                    return inv.status === InvoiceStatus.Paid && paidDate &&
                           paidDate.getMonth() === month &&
                           paidDate.getFullYear() === year;
                })
                .reduce((sum, inv) => sum + calculateDocumentTotal(inv), 0);

        const revenueCurrentMonth = getRevenueForPeriod(currentMonth, currentYear);
        const revenueLastMonth = getRevenueForPeriod(lastMonth, lastMonthYear);
        
        // FIX: Explicitly type revenueTrend to ensure it's assignable to the StatCard's trend prop.
        const revenueTrend: 'up' | 'down' | 'neutral' = revenueCurrentMonth > revenueLastMonth ? 'up' : revenueLastMonth > revenueCurrentMonth ? 'down' : 'neutral';
        const revenuePercentageChange = revenueLastMonth > 0 ? ((revenueCurrentMonth - revenueLastMonth) / revenueLastMonth) * 100 : revenueCurrentMonth > 0 ? 100 : 0;


        const pendingAmount = invoices
            .filter(inv => inv.status === InvoiceStatus.Sent || inv.status === InvoiceStatus.Overdue)
            .reduce((sum, inv) => sum + calculateDocumentTotal(inv), 0);
        
        const acceptedQuotes = quotes.filter(q => q.status === QuoteStatus.Accepted);
        const totalSentOrAcceptedQuotes = quotes.filter(q => q.status === QuoteStatus.Sent || q.status === QuoteStatus.Accepted);
        const conversionRate = totalSentOrAcceptedQuotes.length > 0 ? (acceptedQuotes.length / totalSentOrAcceptedQuotes.length) * 100 : 0;

        const overdueInvoices = invoices.filter(inv => inv.status === InvoiceStatus.Overdue);
        const pendingQuotes = quotes.filter(q => q.status === QuoteStatus.Sent);
            
        return { 
            revenueCurrentMonth, 
            revenueTrend,
            revenuePercentageChange,
            pendingAmount,
            conversionRate,
            overdueInvoices,
            pendingQuotes 
        };
    }, [invoices, quotes]);

    const chartData = useMemo(() => {
        const data: { [key: string]: { entrees: number; devisAcceptes: number } } = {};
        const monthNames = ["Jan", "Fév", "Mar", "Avr", "Mai", "Juin", "Juil", "Août", "Sep", "Oct", "Nov", "Déc"];
        
        invoices.forEach(invoice => {
            if (invoice.status === InvoiceStatus.Paid && invoice.paymentDate) {
                const date = new Date(invoice.paymentDate);
                const monthYear = `${monthNames[date.getMonth()]} '${date.getFullYear().toString().slice(-2)}`;
                if (!data[monthYear]) data[monthYear] = { entrees: 0, devisAcceptes: 0 };
                data[monthYear].entrees += calculateDocumentTotal(invoice);
            }
        });

        quotes.forEach(quote => {
            if (quote.status === QuoteStatus.Accepted) {
                const date = new Date(quote.issueDate);
                const monthYear = `${monthNames[date.getMonth()]} '${date.getFullYear().toString().slice(-2)}`;
                 if (!data[monthYear]) data[monthYear] = { entrees: 0, devisAcceptes: 0 };
                data[monthYear].devisAcceptes += calculateDocumentTotal(quote);
            }
        });
        
        const sortedData = [];
        const today = new Date();
        for (let i = 5; i >= 0; i--) {
            const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
            const monthYear = `${monthNames[d.getMonth()]} '${d.getFullYear().toString().slice(-2)}`;
            sortedData.push({
                name: monthYear,
                entrees: data[monthYear]?.entrees || 0,
                devisAcceptes: data[monthYear]?.devisAcceptes || 0,
            });
        }
        
        return sortedData;
    }, [invoices, quotes]);

    const recentActivity = useMemo(() => {
        const activities: any[] = [];
        invoices.forEach(inv => {
            activities.push({ id: inv.id, type: 'invoice_created', date: inv.issueDate, doc: inv });
            if (inv.status === InvoiceStatus.Paid && inv.paymentDate) {
                activities.push({ id: inv.id + '_paid', type: 'invoice_paid', date: inv.paymentDate, doc: inv });
            }
        });
        quotes.forEach(q => {
             if (q.status === QuoteStatus.Accepted) {
                 activities.push({ id: q.id + '_accepted', type: 'quote_accepted', date: q.issueDate, doc: q });
             }
        });

        return activities
            .sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime())
            .slice(0, 5);
    }, [invoices, quotes]);

    const getClientName = (clientId: string) => clients.find(c => c.id === clientId)?.name || 'N/A';
    const daysOverdue = (dueDate: string) => {
        const due = new Date(dueDate);
        const today = new Date();
        if (due > today) return 0;
        return Math.floor((today.getTime() - due.getTime()) / (1000 * 3600 * 24));
    };


    return (
        <div className="space-y-6">
             <div className="flex flex-col md:flex-row justify-between md:items-center gap-2">
                <div>
                    <h1 className="text-3xl font-bold text-foreground">Bonsoir {settings.companyOwnerFirstName} 👋</h1>
                    <p className="text-muted-foreground mt-1">Voici un aperçu de votre activité.</p>
                </div>
                <div className="flex items-center gap-2">
                     <Button variant="primary">Créer un devis</Button>
                     <Button variant="outline">Créer une facture</Button>
                </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <StatCard 
                    title="CA Encaissé (ce mois-ci)" 
                    value={formatCurrency(stats.revenueCurrentMonth)}
                    trend={stats.revenueTrend}
                    percentage={stats.revenuePercentageChange}
                />
                <StatCard title="En attente de paiement" value={formatCurrency(stats.pendingAmount)} />
                <StatCard title="Taux de conversion (Devis)" value={`${stats.conversionRate.toFixed(1)}%`} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-4 flex flex-col">
                     <h2 className="text-lg font-semibold text-foreground">Actions Requises</h2>
                     <Card>
                        {stats.overdueInvoices.length === 0 && stats.pendingQuotes.length === 0 ? (
                             <div className="text-center py-8">
                                <p className="text-muted-foreground">Tout est à jour. Bravo !</p>
                            </div>
                        ) : (
                            <div className="space-y-4">
                                {stats.overdueInvoices.length > 0 && (
                                    <div>
                                        <h3 className="text-sm font-semibold text-red-600 flex items-center mb-2"><AlertCircle size={16} className="mr-2"/> Factures en retard</h3>
                                        <ul className="divide-y divide-border">
                                            {stats.overdueInvoices.map(inv => (
                                                <li key={inv.id}>
                                                    <button onClick={() => onEditInvoice(inv)} className="w-full text-left py-2 flex justify-between items-center text-sm hover:bg-muted rounded-md px-2">
                                                        <div>
                                                            <p className="font-medium">{inv.invoiceNumber} - {getClientName(inv.clientId)}</p>
                                                            <p className="text-muted-foreground">{daysOverdue(inv.dueDate)} jours de retard</p>
                                                        </div>
                                                        <span className="font-semibold">{formatCurrency(calculateDocumentTotal(inv))}</span>
                                                    </button>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}
                                {stats.pendingQuotes.length > 0 && (
                                     <div>
                                        <h3 className="text-sm font-semibold text-blue-600 flex items-center mb-2"><Clock size={16} className="mr-2"/> Devis en attente de réponse</h3>
                                        <ul className="divide-y divide-border">
                                            {stats.pendingQuotes.map(q => (
                                                <li key={q.id}>
                                                    <button onClick={() => onEditQuote(q)} className="w-full text-left py-2 flex justify-between items-center text-sm hover:bg-muted rounded-md px-2">
                                                        <div>
                                                            <p className="font-medium">{q.quoteNumber} - {getClientName(q.clientId)}</p>
                                                            <p className="text-muted-foreground">Envoyé le {new Date(q.issueDate).toLocaleDateString('fr-FR')}</p>
                                                        </div>
                                                        <span className="font-semibold">{formatCurrency(calculateDocumentTotal(q))}</span>
                                                    </button>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}
                            </div>
                        )}
                    </Card>
                </div>
                <div className="lg:col-span-1 space-y-4 flex flex-col">
                    <h2 className="text-lg font-semibold text-foreground">Activité Récente</h2>
                    <Card>
                        <ul className="space-y-3">
                            {recentActivity.map(item => {
                                const doc = item.doc;
                                let icon, text;
                                switch(item.type) {
                                    case 'invoice_paid':
                                        icon = <div className="bg-green-100 p-1.5 rounded-full"><DollarSign size={16} className="text-green-600" /></div>;
                                        text = <p className="text-sm">Paiement reçu pour <strong>{doc.invoiceNumber}</strong></p>;
                                        break;
                                    case 'quote_accepted':
                                        icon = <div className="bg-blue-100 p-1.5 rounded-full"><CheckCircle size={16} className="text-blue-600" /></div>;
                                        text = <p className="text-sm">Devis <strong>{doc.quoteNumber}</strong> accepté</p>;
                                        break;
                                    case 'invoice_created':
                                    default:
                                        icon = <div className="bg-gray-100 p-1.5 rounded-full"><FilePlus2 size={16} className="text-gray-600" /></div>;
                                        text = <p className="text-sm">Facture <strong>{doc.invoiceNumber}</strong> créée</p>;
                                        break;
                                }
                                return (
                                    <li key={item.id} className="flex items-center gap-3">
                                        {icon}
                                        <div className="flex-1">
                                            {text}
                                            <p className="text-xs text-muted-foreground">{new Date(item.date).toLocaleDateString('fr-FR')}</p>
                                        </div>
                                    </li>
                                )
                            })}
                        </ul>
                    </Card>
                </div>
            </div>

            <Card>
                <div className="flex flex-wrap justify-between items-center mb-4 gap-2">
                     <h2 className="text-lg font-semibold text-foreground">Performance des revenus</h2>
                     <div className="flex items-center gap-2">
                         <div className="flex items-center text-sm"><div className="w-3 h-3 rounded-sm mr-2" style={{backgroundColor: 'hsl(var(--accent))'}}></div>CA Encaissé</div>
                         <div className="flex items-center text-sm"><div className="w-3 h-3 rounded-sm mr-2" style={{backgroundColor: 'hsl(var(--chart-1))'}}></div>Devis Acceptés</div>
                     </div>
                </div>
                <div className="h-80">
                    {chartData.some(d => d.entrees > 0 || d.devisAcceptes > 0) ? (
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={chartData} margin={{ top: 5, right: 0, left: -20, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis dataKey="name" tick={{ fontSize: 12 }} dy={10} tickLine={false} axisLine={false} />
                                <YAxis tick={{ fontSize: 12 }} tickLine={false} axisLine={false} tickFormatter={(value) => `${value / 1000}k`}/>
                                <Tooltip
                                    cursor={{ fill: 'rgba(241, 245, 249, 0.5)' }}
                                    contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '0.5rem' }}
                                    formatter={(value: number) => [formatCurrency(value), '']}
                                />
                                <Bar dataKey="entrees" fill="hsl(var(--accent))" radius={[4, 4, 0, 0]} name="CA Encaissé"/>
                                <Bar dataKey="devisAcceptes" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} name="Devis Acceptés" />
                            </BarChart>
                        </ResponsiveContainer>
                     ) : (
                        <div className="flex flex-col items-center justify-center h-full text-center">
                            <h3 className="font-semibold text-foreground">Aucune donnée à analyser</h3>
                            <p className="text-sm text-muted-foreground mt-1">Les factures payées et devis acceptés apparaîtront ici.</p>
                        </div>
                    )}
                </div>
            </Card>
        </div>
    );
};

export default Dashboard;