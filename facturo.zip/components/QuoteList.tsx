import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Plus, Edit, MoreHorizontal, Download, Send, FileCheck, ArrowUp, ArrowDown, Clock, FileSignature } from 'lucide-react';
import { Quote, Client, QuoteStatus } from '../types';
import Card from './ui/Card';
import Button from './ui/Button';

interface QuoteListProps {
    quotes: Quote[];
    clients: Client[];
    onEditQuote: (quote: Quote) => void;
    onCreateQuote: () => void;
    onDownloadQuote: (quote: Quote) => void;
    onSendQuote: (quote: Quote) => void;
    onConvertToInvoice: (quote: Quote) => void;
}

const getStatusBadge = (status: QuoteStatus) => {
    switch (status) {
        case QuoteStatus.Accepted:
            return <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded-full">Accepté</span>;
        case QuoteStatus.Sent:
            return <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded-full">Envoyé</span>;
        case QuoteStatus.Declined:
            return <span className="bg-red-100 text-red-800 text-xs font-medium px-2.5 py-0.5 rounded-full">Refusé</span>;
        case QuoteStatus.Draft:
            return <span className="bg-gray-100 text-gray-800 text-xs font-medium px-2.5 py-0.5 rounded-full">Brouillon</span>;
        default:
            return null;
    }
};

type SortKey = 'quoteNumber' | 'clientName' | 'issueDate' | 'total';
type SortDirection = 'asc' | 'desc';

const QuoteList: React.FC<QuoteListProps> = ({ quotes, clients, onEditQuote, onCreateQuote, onDownloadQuote, onSendQuote, onConvertToInvoice }) => {
    const [openMenuId, setOpenMenuId] = useState<string | null>(null);
    const [filterStatus, setFilterStatus] = useState<QuoteStatus | 'All'>('All');
    const [sortConfig, setSortConfig] = useState<{ key: SortKey; direction: SortDirection } | null>({ key: 'issueDate', direction: 'desc' });
    const menuRef = useRef<HTMLDivElement>(null);
    
    const getClientName = (clientId: string) => clients.find(c => c.id === clientId)?.name || 'Client inconnu';
    const formatCurrency = (amount: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);

    const calculateTotal = (quote: Quote) => {
        const subtotal = quote.lineItems.reduce((acc, item) => acc + (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0), 0);
        const totalTax = quote.lineItems.reduce((acc, item) => acc + ((Number(item.quantity) || 0) * (Number(item.unitPrice) || 0) * (Number(item.taxRate) || 0)), 0);
        return subtotal + totalTax - (quote.discount || 0);
    };

    const processedQuotes = useMemo(() => {
        let filteredQuotes = [...quotes];

        if (filterStatus !== 'All') {
            filteredQuotes = filteredQuotes.filter(q => q.status === filterStatus);
        }

        if (sortConfig !== null) {
            filteredQuotes.sort((a, b) => {
                let aValue: string | number;
                let bValue: string | number;

                switch (sortConfig.key) {
                    case 'clientName':
                        aValue = getClientName(a.clientId);
                        bValue = getClientName(b.clientId);
                        break;
                    case 'total':
                        aValue = calculateTotal(a);
                        bValue = calculateTotal(b);
                        break;
                    case 'quoteNumber':
                    case 'issueDate':
                        aValue = a[sortConfig.key];
                        bValue = b[sortConfig.key];
                        break;
                }
                
                if (aValue < bValue) {
                    return sortConfig.direction === 'asc' ? -1 : 1;
                }
                if (aValue > bValue) {
                    return sortConfig.direction === 'asc' ? 1 : -1;
                }
                return 0;
            });
        }
        
        return filteredQuotes;
    }, [quotes, filterStatus, sortConfig, clients]);


    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
                setOpenMenuId(null);
            }
        };

        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);
    
    const requestSort = (key: SortKey) => {
        let direction: SortDirection = 'asc';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setSortConfig({ key, direction });
    };

    const SortableHeader = ({ label, sortKey }: { label: string, sortKey: SortKey }) => {
        const isActive = sortConfig?.key === sortKey;
        return (
            <button className="flex items-center gap-1" onClick={() => requestSort(sortKey)}>
                {label}
                {isActive && (sortConfig?.direction === 'asc' ? <ArrowUp size={14} /> : <ArrowDown size={14} />)}
            </button>
        );
    };

    if (quotes.length === 0) {
        return (
            <div className="space-y-8">
                <div className="flex justify-between items-center">
                    <h1 className="text-3xl font-bold">Devis</h1>
                </div>
                <div className="text-center py-20 border-2 border-dashed rounded-lg bg-card">
                    <FileSignature size={48} className="mx-auto text-muted-foreground mb-4" />
                    <h2 className="text-2xl font-semibold text-foreground">Aucun devis pour le moment</h2>
                    <p className="text-muted-foreground mt-2 mb-6">Créez votre premier devis pour l'envoyer à un client.</p>
                    <Button onClick={onCreateQuote}>
                        <Plus size={16} className="mr-2" />
                        Créer un devis
                    </Button>
                </div>
            </div>
        );
    }


    return (
        <div className="space-y-8">
            <div className="flex justify-between items-center">
                <h1 className="text-3xl font-bold">Devis</h1>
                <Button onClick={onCreateQuote}>
                    <Plus size={16} className="mr-2" />
                    Créer un devis
                </Button>
            </div>

            <Card className="bg-card">
                <div className="p-4 border-b">
                    <div className="flex items-center gap-2 flex-wrap">
                        {(['All', ...Object.values(QuoteStatus)] as const).map(status => (
                            <button
                                key={status}
                                onClick={() => setFilterStatus(status)}
                                className={`px-3 py-1 text-sm rounded-full transition-colors ${
                                    filterStatus === status
                                        ? 'bg-accent text-accent-foreground font-semibold'
                                        : 'bg-muted text-muted-foreground hover:bg-secondary'
                                }`}
                            >
                                {status === 'All' ? 'Tous' : status}
                            </button>
                        ))}
                    </div>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="border-b border-border">
                            <tr>
                                <th className="p-4 font-semibold text-sm text-muted-foreground"><SortableHeader label="Numéro" sortKey="quoteNumber" /></th>
                                <th className="p-4 font-semibold text-sm text-muted-foreground"><SortableHeader label="Client" sortKey="clientName" /></th>
                                <th className="p-4 font-semibold text-sm text-muted-foreground"><SortableHeader label="Date d'émission" sortKey="issueDate" /></th>
                                <th className="p-4 font-semibold text-sm text-muted-foreground"><SortableHeader label="Montant" sortKey="total" /></th>
                                <th className="p-4 font-semibold text-sm text-muted-foreground">Statut</th>
                                <th className="p-4 font-semibold text-sm text-muted-foreground text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {processedQuotes.map(quote => {
                                const isExpired = quote.status === QuoteStatus.Sent && new Date(quote.expiryDate) < new Date();
                                return (
                                <tr key={quote.id} className="border-b border-border hover:bg-secondary">
                                    <td className="p-4 font-medium">{quote.quoteNumber}</td>
                                    <td className="p-4 text-secondary-foreground">{getClientName(quote.clientId)}</td>
                                    <td className="p-4 text-secondary-foreground">{new Date(quote.issueDate).toLocaleDateString('fr-FR')}</td>
                                    <td className="p-4 text-secondary-foreground">{formatCurrency(calculateTotal(quote))}</td>
                                    <td className="p-4">
                                        <div className="flex items-center">
                                            {getStatusBadge(quote.status)}
                                            {/* FIX: The `lucide-react` icon components do not accept a `title` prop. Wrapped the icon in a span with a title attribute to provide a tooltip. */}
                                            {isExpired && <span title="Ce devis a expiré"><Clock size={14} className="text-orange-500 ml-1.5" /></span>}
                                        </div>
                                    </td>
                                    <td className="p-4">
                                         <div className="flex items-center justify-end space-x-1">
                                            <button onClick={() => onEditQuote(quote)} className="p-2 text-muted-foreground hover:text-primary rounded-md hover:bg-muted">
                                                <Edit size={16} />
                                            </button>
                                            <div className="relative" ref={openMenuId === quote.id ? menuRef : null}>
                                                <button 
                                                    onMouseDown={(e) => e.stopPropagation()}
                                                    onClick={() => setOpenMenuId(openMenuId === quote.id ? null : quote.id)} 
                                                    className="p-2 text-muted-foreground hover:text-primary rounded-md hover:bg-muted">
                                                    <MoreHorizontal size={16} />
                                                </button>
                                                {openMenuId === quote.id && (
                                                    <div className="absolute right-0 mt-2 w-48 bg-card rounded-md shadow-lg z-20 border border-border">
                                                        <ul className="py-1">
                                                            <li>
                                                                <button
                                                                    onClick={() => { onDownloadQuote(quote); setOpenMenuId(null); }}
                                                                    className="w-full text-left flex items-center px-4 py-2 text-sm text-foreground hover:bg-secondary"
                                                                >
                                                                    <Download size={14} className="mr-2" />
                                                                    Télécharger
                                                                </button>
                                                            </li>
                                                            <li>
                                                                <button
                                                                    onClick={() => { onSendQuote(quote); setOpenMenuId(null); }}
                                                                    className="w-full text-left flex items-center px-4 py-2 text-sm text-foreground hover:bg-secondary"
                                                                >
                                                                    <Send size={14} className="mr-2" />
                                                                    Envoyer
                                                                </button>
                                                            </li>
                                                             {quote.status === QuoteStatus.Accepted && (
                                                                <li>
                                                                    <button
                                                                        onClick={() => { onConvertToInvoice(quote); setOpenMenuId(null); }}
                                                                        className="w-full text-left flex items-center px-4 py-2 text-sm text-foreground hover:bg-secondary"
                                                                    >
                                                                        <FileCheck size={14} className="mr-2" />
                                                                        Convertir en facture
                                                                    </button>
                                                                </li>
                                                            )}
                                                        </ul>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            )})}
                        </tbody>
                    </table>
                     {processedQuotes.length === 0 && (
                         <div className="text-center p-8 text-muted-foreground">
                            Aucun devis ne correspond à vos filtres.
                        </div>
                    )}
                </div>
            </Card>
        </div>
    );
};

export default QuoteList;
