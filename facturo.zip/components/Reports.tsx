import React, { useState, useMemo } from 'react';
import { Download, Search, ArrowUp, ArrowDown } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Invoice, Client, InvoiceStatus } from '../types';
import Card from './ui/Card';
import Button from './ui/Button';
import Input from './ui/Input';

interface ReportsProps {
    invoices: Invoice[];
    clients: Client[];
    calculateTotals: (invoice: Invoice) => { subtotal: number; totalTax: number; netToPay: number; };
    onEditInvoice: (invoice: Invoice) => void;
}

const StatCard: React.FC<{ title: string; value: string; }> = ({ title, value }) => (
    <Card>
        <p className="text-sm font-medium text-muted-foreground">{title}</p>
        <p className="text-2xl font-bold mt-1">{value}</p>
    </Card>
);

type SortKey = 'paymentDate' | 'invoiceNumber' | 'clientName' | 'netToPay';
type SortDirection = 'asc' | 'desc';


const Reports: React.FC<ReportsProps> = ({ invoices, clients, calculateTotals, onEditInvoice }) => {
    const [startDate, setStartDate] = useState<string>(() => {
        const d = new Date();
        d.setMonth(d.getMonth() - 6);
        return d.toISOString().split('T')[0];
    });
    const [endDate, setEndDate] = useState<string>(new Date().toISOString().split('T')[0]);
    const [selectedClientId, setSelectedClientId] = useState<string>('all');
    const [searchQuery, setSearchQuery] = useState<string>('');
    const [sortConfig, setSortConfig] = useState<{ key: SortKey; direction: SortDirection }>({ key: 'paymentDate', direction: 'desc' });


    const formatCurrency = (amount: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);
    const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString('fr-FR');
    const getClientName = (clientId: string) => clients.find(c => c.id === clientId)?.name || 'N/A';

    const receipts = useMemo(() => {
        const start = new Date(startDate);
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999); // Include the whole end day

        let filteredInvoices = invoices.filter(inv => 
            inv.status === InvoiceStatus.Paid && 
            inv.paymentDate &&
            new Date(inv.paymentDate) >= start &&
            new Date(inv.paymentDate) <= end
        );

        if (selectedClientId !== 'all') {
            filteredInvoices = filteredInvoices.filter(inv => inv.clientId === selectedClientId);
        }

        if (searchQuery.trim() !== '') {
            filteredInvoices = filteredInvoices.filter(inv => inv.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()));
        }

        filteredInvoices.sort((a, b) => {
            let aValue: string | number;
            let bValue: string | number;

            switch (sortConfig.key) {
                case 'clientName':
                    aValue = getClientName(a.clientId);
                    bValue = getClientName(b.clientId);
                    break;
                case 'netToPay':
                    aValue = calculateTotals(a).netToPay;
                    bValue = calculateTotals(b).netToPay;
                    break;
                case 'paymentDate':
                    aValue = a.paymentDate!;
                    bValue = b.paymentDate!;
                    break;
                case 'invoiceNumber':
                default:
                    aValue = a.invoiceNumber;
                    bValue = b.invoiceNumber;
                    break;
            }
            
            if (aValue < bValue) {
                return sortConfig.direction === 'asc' ? -1 : 1;
            }
            if (aValue > bValue) {
                return sortConfig.direction === 'asc' ? 1 : -1;
            }
            return 0;
        });

        return filteredInvoices;
    }, [invoices, startDate, endDate, selectedClientId, searchQuery, sortConfig]);
    
    const summary = useMemo(() => {
        let totalRevenue = 0;
        let totalTax = 0;

        receipts.forEach(receipt => {
            const totals = calculateTotals(receipt);
            totalRevenue += totals.netToPay;
            totalTax += totals.totalTax;
        });

        return { totalRevenue, totalTax, transactionCount: receipts.length };
    }, [receipts, calculateTotals]);

    const chartData = useMemo(() => {
        const monthNames = ["Jan", "Fév", "Mar", "Avr", "Mai", "Juin", "Juil", "Août", "Sep", "Oct", "Nov", "Déc"];
        const monthlyRevenue: { [key: string]: number } = {};

        receipts.forEach(receipt => {
            const paymentDate = new Date(receipt.paymentDate!);
            const monthYearKey = `${paymentDate.getFullYear()}-${String(paymentDate.getMonth()).padStart(2, '0')}`;
            const revenue = calculateTotals(receipt).netToPay;
            
            if (monthlyRevenue[monthYearKey]) {
                monthlyRevenue[monthYearKey] += revenue;
            } else {
                monthlyRevenue[monthYearKey] = revenue;
            }
        });
        
        return Object.entries(monthlyRevenue)
            .map(([key, Chiffre_d_affaires]) => {
                const [year, monthIndex] = key.split('-');
                const name = `${monthNames[parseInt(monthIndex, 10)]} '${year.slice(-2)}`;
                return { name, "Chiffre d'affaires": Chiffre_d_affaires, key };
            })
            .sort((a, b) => a.key.localeCompare(b.key));
    }, [receipts]);
    
    const handleExportCSV = () => {
        let csvContent = "data:text/csv;charset=utf-8,";
        csvContent += "Date d'encaissement,Numéro de facture,Client,Libellé,Mode de paiement,Total HT,TVA,Total TTC\n";

        receipts.forEach(receipt => {
            const totals = calculateTotals(receipt);
            const row = [
                formatDate(receipt.paymentDate!),
                receipt.invoiceNumber,
                `"${getClientName(receipt.clientId).replace(/"/g, '""')}"`,
                `"Paiement facture ${receipt.invoiceNumber}"`,
                receipt.paymentMethod || 'N/A',
                totals.subtotal.toFixed(2),
                totals.totalTax.toFixed(2),
                totals.netToPay.toFixed(2)
            ].join(',');
            csvContent += row + "\n";
        });
        
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", `livre-recettes_${startDate}_${endDate}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    
    const requestSort = (key: SortKey) => {
        let direction: SortDirection = 'asc';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setSortConfig({ key, direction });
    };

    const SortableHeader: React.FC<{ label: string; sortKey: SortKey; className?: string }> = ({ label, sortKey, className = '' }) => {
        const isActive = sortConfig?.key === sortKey;
        return (
            <button className={`flex items-center gap-1 font-semibold text-sm text-muted-foreground ${className}`} onClick={() => requestSort(sortKey)}>
                {label}
                {isActive && (sortConfig?.direction === 'asc' ? <ArrowUp size={14} /> : <ArrowDown size={14} />)}
            </button>
        );
    };


    return (
        <div className="space-y-8">
            <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                <h1 className="text-3xl font-bold">Livre des recettes</h1>
                 <Button onClick={handleExportCSV} variant="outline">
                    <Download size={16} className="mr-2" />
                    Exporter en CSV
                </Button>
            </div>

            <Card>
                <div className="p-4 border-b">
                    <h3 className="font-semibold mb-4 text-lg">Analyse et Synthèse</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end mb-6">
                        <Input label="Date de début" type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
                        <Input label="Date de fin" type="date" value={endDate} onChange={e => setEndDate(e.target.value)} />
                        <div>
                            <label className="block text-sm font-medium text-muted-foreground mb-1">Client</label>
                            <select
                                value={selectedClientId}
                                onChange={e => setSelectedClientId(e.target.value)}
                                className="flex h-10 w-full rounded-md border border-border bg-card px-3 py-2 text-sm"
                            >
                                <option value="all">Tous les clients</option>
                                {clients.map(client => (
                                    <option key={client.id} value={client.id}>{client.name}</option>
                                ))}
                            </select>
                        </div>
                         <div className="relative">
                             <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                             <Input 
                                type="text"
                                placeholder="Rechercher par n° de facture..."
                                className="pl-9 w-full"
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                             />
                        </div>
                    </div>
                </div>
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4">
                    <StatCard title="CA Encaissé (TTC)" value={formatCurrency(summary.totalRevenue)} />
                    <StatCard title="TVA Collectée" value={formatCurrency(summary.totalTax)} />
                    <StatCard title="Transactions" value={String(summary.transactionCount)} />
                </div>
            </Card>

             <Card>
                <h3 className="font-semibold mb-4 text-lg p-4">Évolution des encaissements</h3>
                <div className="h-80 px-4 pb-4">
                    {chartData.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={chartData} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis dataKey="name" tick={{ fontSize: 12 }} dy={10} tickLine={false} axisLine={false} />
                                <YAxis tick={{ fontSize: 12 }} tickLine={false} axisLine={false} tickFormatter={(value) => `${value / 1000}k€`}/>
                                <Tooltip
                                    cursor={{ fill: 'rgba(241, 245, 249, 0.5)' }}
                                    contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '0.5rem' }}
                                    formatter={(value: number) => [formatCurrency(value), "Chiffre d'affaires"]}
                                />
                                <Bar dataKey="Chiffre d'affaires" fill="hsl(var(--accent))" radius={[4, 4, 0, 0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    ) : (
                        <div className="flex items-center justify-center h-full text-muted-foreground">
                            <p>Aucune donnée à afficher pour la période et les filtres sélectionnés.</p>
                        </div>
                    )}
                </div>
            </Card>

            <Card>
                <h3 className="font-semibold text-lg p-4">Détail des transactions</h3>
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                         <thead className="border-b">
                            <tr>
                                <th className="p-4"><SortableHeader label="Date encaissement" sortKey="paymentDate" /></th>
                                <th className="p-4"><SortableHeader label="Facture" sortKey="invoiceNumber" /></th>
                                <th className="p-4"><SortableHeader label="Client" sortKey="clientName" /></th>
                                <th className="p-4"><SortableHeader label="Montant TTC" sortKey="netToPay" /></th>
                                <th className="p-4 font-semibold text-sm text-muted-foreground">Mode de paiement</th>
                            </tr>
                        </thead>
                         <tbody>
                            {receipts.length > 0 ? (
                                receipts.map(receipt => {
                                    const totals = calculateTotals(receipt);
                                    return (
                                        <tr key={receipt.id} className="border-b last:border-b-0 hover:bg-secondary">
                                            <td className="p-4 font-medium">{formatDate(receipt.paymentDate!)}</td>
                                            <td 
                                                className="p-4 text-primary font-semibold hover:underline cursor-pointer"
                                                onClick={() => onEditInvoice(receipt)}
                                            >
                                                {receipt.invoiceNumber}
                                            </td>
                                            <td className="p-4">{getClientName(receipt.clientId)}</td>
                                            <td className="p-4 font-medium">{formatCurrency(totals.netToPay)}</td>
                                            <td className="p-4 text-muted-foreground">{receipt.paymentMethod}</td>
                                        </tr>
                                    );
                                })
                            ) : (
                                <tr>
                                    <td colSpan={5} className="text-center p-8 text-muted-foreground">
                                        Aucune recette ne correspond aux filtres sélectionnés.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>

        </div>
    );
};

export default Reports;