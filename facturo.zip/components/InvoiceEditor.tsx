import React, { useState, useEffect } from 'react';
import { Trash2, Plus } from 'lucide-react';
import { Invoice, Client, LineItem, InvoiceStatus, Settings } from '../types';
import Modal from './ui/Modal';
import Input from './ui/Input';
import Button from './ui/Button';

interface InvoiceEditorProps {
    invoice: Invoice | null;
    clients: Client[];
    settings: Settings;
    onClose: () => void;
    onSave: (invoice: Invoice) => void;
}

const tvaRates = [
    { label: 'Normal (20%)', value: 0.20 },
    { label: 'Intermédiaire (10%)', value: 0.10 },
    { label: 'Réduit (5.5%)', value: 0.055 },
    { label: 'Exonéré (0%)', value: 0 },
];

const paymentMethods = [
    "Virement bancaire",
    "Carte de crédit",
    "PayPal",
    "Chèque",
    "Espèces",
    "Prélèvement SEPA",
    "Autre"
];

const InvoiceEditor: React.FC<InvoiceEditorProps> = ({ invoice, clients, settings, onClose, onSave }) => {
    const getInitialInvoiceState = () => {
        if (invoice) return {
            ...invoice,
            paymentDate: invoice.paymentDate || '',
            paymentMethod: invoice.paymentMethod || 'Virement bancaire'
        };

        const issueDate = new Date();
        const dueDate = new Date();
        // Super simple logic for due date, can be improved
        const termDays = parseInt(settings.defaultPaymentTerms.match(/\d+/)?.[0] || '30', 10);
        dueDate.setDate(issueDate.getDate() + termDays);

        return {
            id: '',
            invoiceNumber: '',
            clientId: clients[0]?.id || '',
            issueDate: issueDate.toISOString().split('T')[0],
            dueDate: dueDate.toISOString().split('T')[0],
            lineItems: [{ id: `li_${Date.now()}`, description: '', quantity: 1, unitPrice: 0, taxRate: settings.defaultTaxRate }],
            status: InvoiceStatus.Draft,
            discount: 0,
            acompte: 0,
            paymentDate: '',
            paymentMethod: 'Virement bancaire'
        };
    };
    
    const [editedInvoice, setEditedInvoice] = useState<Invoice>(getInitialInvoiceState());

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        
        const newInvoiceState = { ...editedInvoice, [name]: value };

        if (name === 'status' && value === InvoiceStatus.Paid && !editedInvoice.paymentDate) {
            newInvoiceState.paymentDate = new Date().toISOString().split('T')[0];
        }

        if (name === 'discount' || name === 'acompte') {
            const numValue = parseFloat(value);
            newInvoiceState[name] = isNaN(numValue) ? 0 : numValue;
        }
        
        setEditedInvoice(newInvoiceState);
    };

    const handleLineItemChange = (index: number, field: keyof LineItem, value: string) => {
        const newLineItems = [...editedInvoice.lineItems];
        const item = { ...newLineItems[index] };

        if (field === 'description') {
            item.description = value;
        } else if (field === 'quantity' || field === 'unitPrice' || field === 'taxRate') {
            const numValue = parseFloat(value);
            item[field] = isNaN(numValue) ? '' : numValue;
        }
        
        newLineItems[index] = item;
        setEditedInvoice(prev => ({ ...prev, lineItems: newLineItems }));
    };


    const addLineItem = () => {
        setEditedInvoice(prev => ({
            ...prev,
            lineItems: [...prev.lineItems, { id: `li_${Date.now()}`, description: '', quantity: 1, unitPrice: 0, taxRate: settings.defaultTaxRate }]
        }));
    };

    const removeLineItem = (index: number) => {
        const newLineItems = editedInvoice.lineItems.filter((_, i) => i !== index);
        setEditedInvoice(prev => ({ ...prev, lineItems: newLineItems }));
    };

    const subtotal = editedInvoice.lineItems.reduce((acc, item) => acc + (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0), 0);
    const totalTax = editedInvoice.lineItems.reduce((acc, item) => acc + ((Number(item.quantity) || 0) * (Number(item.unitPrice) || 0) * (Number(item.taxRate) || 0)), 0);
    const total = subtotal + totalTax;
    const netToPay = total - (editedInvoice.discount || 0) - (editedInvoice.acompte || 0);
    
    const formatCurrency = (amount: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);

    const isFormValid = editedInvoice.clientId &&
                        editedInvoice.lineItems.length > 0 &&
                        editedInvoice.lineItems.every(item => 
                            item.description.trim() !== '' &&
                            (Number(item.quantity) > 0) &&
                            (Number(item.unitPrice) >= 0)
                        );

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!isFormValid) {
            alert("Veuillez vérifier que toutes les lignes ont une description, une quantité positive et un prix positif ou nul.");
            return;
        }
        onSave(editedInvoice);
    };

    return (
        <Modal title={invoice ? 'Modifier la facture' : 'Créer une facture'} onClose={onClose}>
            <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-muted-foreground mb-1">Client</label>
                        <select name="clientId" value={editedInvoice.clientId} onChange={handleInputChange} className="w-full border-border bg-card rounded-md shadow-sm focus:ring-primary focus:border-primary h-10 px-3">
                            {clients.map(client => (
                                <option key={client.id} value={client.id}>{client.name}</option>
                            ))}
                        </select>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-muted-foreground mb-1">Statut</label>
                        <select name="status" value={editedInvoice.status} onChange={handleInputChange} className="w-full border-border bg-card rounded-md shadow-sm focus:ring-primary focus:border-primary h-10 px-3">
                            {Object.values(InvoiceStatus).map(status => (
                                <option key={status} value={status}>{status}</option>
                            ))}
                        </select>
                    </div>
                    <Input label="Date d'émission" type="date" name="issueDate" value={editedInvoice.issueDate} onChange={handleInputChange} />
                    <Input label="Date d'échéance" type="date" name="dueDate" value={editedInvoice.dueDate} onChange={handleInputChange} />
                </div>
                
                {editedInvoice.status === InvoiceStatus.Paid && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t">
                        <Input 
                            label="Date de paiement" 
                            type="date" 
                            name="paymentDate" 
                            value={editedInvoice.paymentDate || ''} 
                            onChange={handleInputChange} 
                            required 
                        />
                        <div>
                            <label className="block text-sm font-medium text-muted-foreground mb-1">Moyen de paiement</label>
                            <select 
                                name="paymentMethod" 
                                value={editedInvoice.paymentMethod || ''} 
                                onChange={handleInputChange} 
                                className="w-full border-border bg-card rounded-md shadow-sm focus:ring-primary focus:border-primary h-10 px-3"
                            >
                                {paymentMethods.map(method => <option key={method} value={method}>{method}</option>)}
                            </select>
                        </div>
                    </div>
                )}

                <div className="space-y-2">
                    <h3 className="text-lg font-medium">Lignes de la facture</h3>

                    {/* Headers */}
                    <div className="hidden md:grid grid-cols-12 gap-2 items-center text-sm font-medium text-muted-foreground mt-4 pb-2 border-b">
                        <div className="col-span-4">Description</div>
                        <div className="col-span-2 text-center">Quantité</div>
                        <div className="col-span-2 text-right">Prix U. HT</div>
                        <div className="col-span-2 text-center">TVA</div>
                        <div className="col-span-1 text-right">Total HT</div>
                        <div className="col-span-1"></div>
                    </div>

                    {editedInvoice.lineItems.map((item, index) => {
                        const lineTotal = (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0);
                        return (
                            <div key={item.id} className="grid grid-cols-12 gap-2 items-center border-b last:border-b-0 py-2">
                                <div className="col-span-12 md:col-span-4"><Input aria-label="Description" placeholder="Description" value={item.description} onChange={e => handleLineItemChange(index, 'description', e.target.value)} /></div>
                                <div className="col-span-4 md:col-span-2"><Input aria-label="Quantité" placeholder="Qté" type="number" value={item.quantity} onChange={e => handleLineItemChange(index, 'quantity', e.target.value)} className="text-center" /></div>
                                <div className="col-span-4 md:col-span-2"><Input aria-label="Prix Unitaire" placeholder="Prix U." type="number" value={item.unitPrice} onChange={e => handleLineItemChange(index, 'unitPrice', e.target.value)} className="text-right" /></div>
                                <div className="col-span-4 md:col-span-2">
                                    <select
                                        aria-label="TVA"
                                        value={item.taxRate}
                                        onChange={e => handleLineItemChange(index, 'taxRate', e.target.value)}
                                        className="flex h-10 w-full rounded-md border border-border bg-card px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
                                    >
                                        {tvaRates.map(rate => (
                                            <option key={rate.label} value={rate.value}>
                                                {rate.label}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div className="col-span-8 md:col-span-1 text-right font-medium text-foreground flex items-center justify-end h-10">
                                    {formatCurrency(lineTotal)}
                                </div>
                                <div className="col-span-4 md:col-span-1 flex justify-end">
                                    <Button type="button" variant="ghost" onClick={() => removeLineItem(index)} className="px-2 py-2">
                                        <Trash2 size={16} className="text-red-500"/>
                                    </Button>
                                </div>
                            </div>
                        )
                    })}
                    <Button type="button" variant="outline" onClick={addLineItem} className="mt-4">
                         <Plus size={16} className="mr-2" />
                         Ajouter une ligne
                    </Button>
                </div>

                <div className="flex justify-end">
                    <div className="w-full md:w-2/5 space-y-2 text-sm">
                        <div className="flex justify-between"><span>Sous-total HT</span><span>{formatCurrency(subtotal)}</span></div>
                        <div className="flex justify-between"><span>TVA</span><span>{formatCurrency(totalTax)}</span></div>
                        <div className="flex justify-between font-semibold"><span>Total TTC</span><span>{formatCurrency(total)}</span></div>
                         <div className="flex justify-between items-center pt-2">
                            <span>Remise</span>
                            <div className="w-28">
                               <Input type="number" name="discount" value={editedInvoice.discount} onChange={handleInputChange} className="text-right" placeholder="0.00" />
                            </div>
                        </div>
                        <div className="flex justify-between items-center">
                            <span>Acompte</span>
                            <div className="w-28">
                               <Input type="number" name="acompte" value={editedInvoice.acompte} onChange={handleInputChange} className="text-right" placeholder="0.00" />
                            </div>
                        </div>
                        <div className="flex justify-between font-bold text-lg border-t pt-2 mt-2"><span>Net à payer</span><span>{formatCurrency(netToPay)}</span></div>
                    </div>
                </div>

                <div className="flex justify-end space-x-3 pt-4">
                    <Button type="button" variant="outline" onClick={onClose}>Annuler</Button>
                    <Button type="submit" disabled={!isFormValid}>Enregistrer</Button>
                </div>
            </form>
        </Modal>
    );
};

export default InvoiceEditor;