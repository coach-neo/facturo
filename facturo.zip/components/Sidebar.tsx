import React from 'react';
import { LayoutDashboard, Users, FileText, FileSignature, Book, X, Briefcase } from 'lucide-react';
import { Page } from '../types';

interface SidebarProps {
    currentPage: Page;
    setCurrentPage: (page: Page) => void;
    isMobileMenuOpen: boolean;
    setIsMobileMenuOpen: (isOpen: boolean) => void;
}

interface NavItemProps {
    icon: React.ElementType;
    label: string;
    page: Page;
    currentPage: Page;
    onClick: (page: Page) => void;
}

const NavItem: React.FC<NavItemProps> = ({ icon: Icon, label, page, currentPage, onClick }) => {
    const isActive = currentPage === page;
    return (
        <li>
            <a
                href="#"
                onClick={(e) => {
                    e.preventDefault();
                    onClick(page);
                }}
                className={`flex items-center p-3 rounded-lg transition-colors ${
                    isActive
                        ? 'bg-accent text-accent-foreground'
                        : 'text-white/70 hover:bg-white/10 hover:text-white'
                }`}
            >
                {/* FIX: Changed from React.cloneElement to directly rendering the icon component. This resolves a TypeScript error and is a cleaner pattern. */}
                <Icon size={20} className="mr-3" />
                <span className="font-medium">{label}</span>
            </a>
        </li>
    );
};


const Sidebar: React.FC<SidebarProps> = ({ currentPage, setCurrentPage, isMobileMenuOpen, setIsMobileMenuOpen }) => {
    
    const handleNavigation = (page: Page) => {
        setCurrentPage(page);
        if (isMobileMenuOpen) {
            setIsMobileMenuOpen(false);
        }
    };

    const navItems = [
        { icon: Briefcase, label: Page.Settings, page: Page.Settings },
        { icon: LayoutDashboard, label: Page.Dashboard, page: Page.Dashboard },
        { icon: Users, label: Page.Clients, page: Page.Clients },
        { icon: FileSignature, label: Page.Quotes, page: Page.Quotes },
        { icon: FileText, label: Page.Invoices, page: Page.Invoices },
        { icon: Book, label: Page.Reports, page: Page.Reports },
    ];

    return (
         <>
            {/* Overlay for mobile */}
            {isMobileMenuOpen && (
                <div 
                    className="fixed inset-0 bg-black/60 z-30 md:hidden"
                    onClick={() => setIsMobileMenuOpen(false)}
                ></div>
            )}
            
            <aside className={`fixed top-0 left-0 h-full w-64 bg-black text-white z-40 transform transition-transform duration-300 ease-in-out md:translate-x-0 ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
                <div className="flex flex-col h-full">
                    <div className="flex items-center justify-between p-6 h-[69px] border-b border-white/20">
                        <h1 className="font-ferryman text-3xl tracking-wider">facturo</h1>
                         <button onClick={() => setIsMobileMenuOpen(false)} className="md:hidden text-white/70 hover:text-white">
                            <X size={24} />
                        </button>
                    </div>

                    <nav className="flex-1 p-4">
                        <ul className="space-y-2">
                            {navItems.map(item => (
                                <NavItem
                                    key={item.page}
                                    icon={item.icon}
                                    label={item.label}
                                    page={item.page}
                                    currentPage={currentPage}
                                    onClick={handleNavigation}
                                />
                            ))}
                        </ul>
                    </nav>
                    
                    <div className="p-4 border-t border-white/20">
                         <div className="bg-white/10 p-4 rounded-lg text-center">
                            <h3 className="font-semibold">Passez à Pro</h3>
                            <p className="text-sm text-white/70 mt-1">Débloquez toutes les fonctionnalités et profitez d'un support premium.</p>
                            <button className="mt-4 w-full bg-accent text-accent-foreground text-sm font-semibold py-2 rounded-md hover:bg-accent/90 transition-colors">
                                Mettre à niveau
                            </button>
                        </div>
                    </div>
                </div>
            </aside>
        </>
    );
};

export default Sidebar;