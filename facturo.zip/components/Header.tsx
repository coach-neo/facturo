import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Menu, Search, User, FileText, X as XIcon, LogOut } from 'lucide-react';
import { Client, Invoice, Settings as AppSettings } from '../types';

interface HeaderProps {
    onMenuClick: () => void;
    clients: Client[];
    invoices: Invoice[];
    onSearchSelect: (item: Client | Invoice) => void;
    settings: AppSettings;
    onLogout: () => void;
}

const GlobalSearch: React.FC<{
    clients: Client[];
    invoices: Invoice[];
    onSelect: (item: Client | Invoice) => void;
}> = ({ clients, invoices, onSelect }) => {
    const [query, setQuery] = useState('');
    const [suggestions, setSuggestions] = useState<(Client | Invoice)[]>([]);
    const [isFocused, setIsFocused] = useState(false);
    const searchContainerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
                setIsFocused(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setQuery(value);
        if (value.length > 1) {
            const lowerCaseValue = value.toLowerCase();
            const clientResults = clients.filter(c => c.name.toLowerCase().includes(lowerCaseValue));
            const invoiceResults = invoices.filter(i => i.invoiceNumber.toLowerCase().includes(lowerCaseValue));
            setSuggestions([...clientResults, ...invoiceResults]);
        } else {
            setSuggestions([]);
        }
    };

    const handleSelect = (item: Client | Invoice) => {
        onSelect(item);
        setQuery('');
        setSuggestions([]);
        setIsFocused(false);
    };
    
    const showSuggestions = isFocused && query.length > 1;

    return (
        <div ref={searchContainerRef} className="relative hidden sm:block">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
            <input 
                type="text" 
                placeholder="Rechercher client, facture..." 
                className="bg-muted h-9 w-64 rounded-md pl-9 pr-8 text-sm focus:ring-1 focus:ring-ring" 
                value={query}
                onChange={handleSearch}
                onFocus={() => setIsFocused(true)}
            />
            {query && (
                <button onClick={() => setQuery('')} className="absolute right-2 top-1/2 -translate-y-1/2">
                    <XIcon size={16} className="text-muted-foreground" />
                </button>
            )}

            {showSuggestions && (
                <div className="absolute top-full mt-2 w-full bg-card rounded-md shadow-lg z-20 border border-border max-h-80 overflow-y-auto">
                    {suggestions.length > 0 ? (
                        <ul>
                            {suggestions.map(item => (
                                <li key={item.id}>
                                    <button
                                        onClick={() => handleSelect(item)}
                                        className="w-full flex items-center gap-3 px-4 py-2 text-sm text-foreground hover:bg-secondary cursor-pointer text-left"
                                    >
                                        {'invoiceNumber' in item 
                                            ? <FileText size={16} className="text-muted-foreground shrink-0" /> 
                                            : <User size={16} className="text-muted-foreground shrink-0" />
                                        }
                                        <div className="flex-grow overflow-hidden">
                                            <p className="font-medium truncate">
                                                {'invoiceNumber' in item ? item.invoiceNumber : item.name}
                                            </p>
                                            <p className="text-xs text-muted-foreground truncate">
                                                {'invoiceNumber' in item ? `Pour: ${clients.find(c => c.id === item.clientId)?.name || 'Inconnu'}` : item.email}
                                            </p>
                                        </div>
                                        <span className="text-xs bg-muted text-muted-foreground px-1.5 py-0.5 rounded-sm">
                                            {'invoiceNumber' in item ? 'Facture' : 'Client'}
                                        </span>
                                    </button>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p className="p-4 text-sm text-muted-foreground text-center">Aucun résultat trouvé.</p>
                    )}
                </div>
            )}
        </div>
    );
};


const Header: React.FC<HeaderProps> = ({ onMenuClick, clients, invoices, onSearchSelect, settings, onLogout }) => {
    const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
    const profileMenuRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (profileMenuRef.current && !profileMenuRef.current.contains(event.target as Node)) {
                setIsProfileMenuOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const userInitials = useMemo(() => {
        const firstName = settings.companyOwnerFirstName || '';
        const lastName = settings.companyOwnerLastName || '';
        return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
    }, [settings]);


    return (
        <header className="sticky top-0 z-30 bg-card shadow-sm border-b px-4 md:px-8 py-3">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <button onClick={onMenuClick} className="md:hidden text-muted-foreground">
                        <Menu size={24} />
                    </button>
                    <GlobalSearch clients={clients} invoices={invoices} onSelect={onSearchSelect} />
                </div>

                <div className="flex items-center gap-2 sm:gap-4">
                     <div className="relative" ref={profileMenuRef}>
                        <button onClick={() => setIsProfileMenuOpen(prev => !prev)}>
                            <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold text-sm cursor-pointer">
                               {userInitials}
                            </div>
                        </button>
                        {isProfileMenuOpen && (
                             <div className="absolute right-0 mt-2 w-64 bg-card rounded-md shadow-lg z-20 border border-border">
                                <div className="p-4 border-b">
                                    <p className="font-semibold">{`${settings.companyOwnerFirstName} ${settings.companyOwnerLastName}`}</p>
                                    <p className="text-sm text-muted-foreground">demo-utilisateur@facturo.app</p>
                                </div>
                                <ul className="py-2">
                                    <li>
                                        <button 
                                            onClick={onLogout}
                                            className="w-full text-left flex items-center px-4 py-2 text-sm text-foreground hover:bg-secondary">
                                            <LogOut size={14} className="mr-2" />
                                            Se déconnecter
                                        </button>
                                    </li>
                                </ul>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;