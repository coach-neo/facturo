import React, { useState, useMemo } from 'react';
import { Image, CheckCircle } from 'lucide-react';
import { Settings as AppSettings } from '../types';
import Card from './ui/Card';
import Input from './ui/Input';
import Button from './ui/Button';

interface SettingsProps {
    settings: AppSettings;
    onSave: (settings: AppSettings) => void;
}

const legalStatuses = [
  'Entreprise Individuelle (EI)',
  'Micro-entreprise',
  'EIRL (Statut en voie d\'extinction)',
  'EURL (Entreprise Unipersonnelle à Responsabilité Limitée)',
  'SARL (Société à Responsabilité Limitée)',
  'SASU (Société par Actions Simplifiée Unipersonnelle)',
  'SAS (Société par Actions Simplifiée)',
  'SA (Société Anonyme)',
  'SNC (Société en Nom Collectif)',
  'SCOP (Société Coopérative de Production)',
  'Association',
  'Autre',
];

const Settings: React.FC<SettingsProps> = ({ settings, onSave }) => {
    const [currentSettings, setCurrentSettings] = useState<AppSettings>(settings);
    const [logoPreview, setLogoPreview] = useState<string | null>(settings.logoUrl);
    const [isSaved, setIsSaved] = useState(false);

    const isSoleProprietorshipLike = useMemo(() => {
        return currentSettings.legalStatus.includes('Entreprise Individuelle') ||
               currentSettings.legalStatus.includes('Micro-entreprise') ||
               currentSettings.legalStatus.includes('EIRL');
    }, [currentSettings.legalStatus]);
    
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, type } = e.target;
        
        if (type === 'checkbox') {
            const { checked } = e.target as HTMLInputElement;
            setCurrentSettings(prev => ({ ...prev, [name]: checked }));
            return;
        }

        const { value } = e.target;
        let processedValue: string | number = value;
        if (type === 'number') {
            processedValue = value === '' ? '' : parseFloat(value);
        }

        setCurrentSettings(prev => ({ 
            ...prev, 
            [name]: processedValue,
            // also update the old isSoleProprietorship flag for compatibility if needed elsewhere
            ...(name === 'legalStatus' && { 
                isSoleProprietorship: value.includes('Entreprise Individuelle') || value.includes('Micro-entreprise') || value.includes('EIRL')
            })
        }));
    };

    const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onloadend = () => {
                const result = reader.result as string;
                setLogoPreview(result);
                setCurrentSettings(prev => ({...prev, logoUrl: result}));
            };
            reader.readAsDataURL(file);
        }
    };

    const isFormValid = useMemo(() => {
        return currentSettings.companyName?.trim() !== '' &&
               currentSettings.companyAddress?.trim() !== '' &&
               currentSettings.legalInfo?.trim() !== '' &&
               (!isSoleProprietorshipLike || (currentSettings.companyOwnerFirstName?.trim() !== '' && currentSettings.companyOwnerLastName?.trim() !== '')) &&
               currentSettings.bankName?.trim() !== '' &&
               currentSettings.iban?.trim() !== '' &&
               currentSettings.bic?.trim() !== '' &&
               currentSettings.invoicePrefix?.trim() !== '' &&
               currentSettings.quotePrefix?.trim() !== '' &&
               Number(currentSettings.nextInvoiceNumber) > 0 &&
               Number(currentSettings.nextQuoteNumber) > 0;
    }, [currentSettings, isSoleProprietorshipLike]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!isFormValid) {
            alert("Veuillez remplir tous les champs obligatoires.");
            return;
        }
        onSave(currentSettings);
        setIsSaved(true);
        setTimeout(() => setIsSaved(false), 3000);
    };

    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold text-primary">Mon entreprise</h1>
            <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 space-y-6">
                        <Card>
                            <h2 className="text-xl font-semibold mb-4">Informations sur l'entreprise</h2>
                            <div className="space-y-4">
                                <Input label="Nom de l'entreprise (ou nom commercial)" name="companyName" value={currentSettings.companyName} onChange={handleChange} required />
                                
                                <div>
                                    <label className="block text-sm font-medium text-muted-foreground mb-1">Statut Juridique</label>
                                    <select name="legalStatus" value={currentSettings.legalStatus} onChange={handleChange} className="w-full border border-border bg-card text-sm rounded-md shadow-sm focus:ring-primary focus:border-primary h-10 px-3">
                                        {legalStatuses.map(status => (
                                            <option key={status} value={status}>{status}</option>
                                        ))}
                                    </select>
                                </div>

                                {isSoleProprietorshipLike && (
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 border rounded-md bg-card">
                                        <p className="col-span-full text-sm text-muted-foreground -mt-1 mb-2">Pour une entreprise en nom propre, votre nom est légalement requis sur les documents.</p>
                                        <Input label="Prénom du dirigeant" name="companyOwnerFirstName" value={currentSettings.companyOwnerFirstName} onChange={handleChange} required={isSoleProprietorshipLike} />
                                        <Input label="Nom du dirigeant" name="companyOwnerLastName" value={currentSettings.companyOwnerLastName} onChange={handleChange} required={isSoleProprietorshipLike} />
                                    </div>
                                )}

                                <div>
                                    <label className="block text-sm font-medium text-muted-foreground mb-1">Adresse</label>
                                    <textarea name="companyAddress" value={currentSettings.companyAddress} onChange={handleChange} rows={3} className="w-full border border-border bg-card p-3 text-sm rounded-md shadow-sm focus:ring-primary focus:border-primary" required></textarea>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-muted-foreground mb-1">Mentions légales</label>
                                    <textarea name="legalInfo" value={currentSettings.legalInfo} onChange={handleChange} rows={4} className="w-full border border-border bg-card p-3 text-sm rounded-md shadow-sm focus:ring-primary focus:border-primary" placeholder="SIRET, TVA, etc." required></textarea>
                                </div>
                            </div>
                        </Card>
                        
                        <Card>
                             <h2 className="text-xl font-semibold mb-4">Informations Bancaires</h2>
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <Input label="Nom de la banque" name="bankName" value={currentSettings.bankName} onChange={handleChange} required/>
                                <Input label="Lien de paiement en ligne (Optionnel)" name="paymentLink" value={currentSettings.paymentLink} onChange={handleChange} placeholder="https://paypal.me/votrecompte" />
                                <Input label="IBAN" name="iban" value={currentSettings.iban} onChange={handleChange} required />
                                <Input label="BIC / SWIFT" name="bic" value={currentSettings.bic} onChange={handleChange} required />
                             </div>
                        </Card>
                        
                        <Card>
                            <h2 className="text-xl font-semibold mb-4">Numérotation des Documents</h2>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <Input label="Préfixe Factures" name="invoicePrefix" value={currentSettings.invoicePrefix} onChange={handleChange} required />
                                <Input label="Prochain numéro de facture" name="nextInvoiceNumber" type="number" min="1" value={currentSettings.nextInvoiceNumber} onChange={handleChange} required />
                                <Input label="Préfixe Devis" name="quotePrefix" value={currentSettings.quotePrefix} onChange={handleChange} required />
                                <Input label="Prochain numéro de devis" name="nextQuoteNumber" type="number" min="1" value={currentSettings.nextQuoteNumber} onChange={handleChange} required />
                            </div>
                        </Card>

                        <Card>
                            <h2 className="text-xl font-semibold mb-4">Valeurs par défaut</h2>
                             <div className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium text-muted-foreground mb-1">Taux de TVA par défaut</label>
                                     <select name="defaultTaxRate" value={currentSettings.defaultTaxRate} onChange={handleChange} className="w-full border border-border bg-card text-sm rounded-md shadow-sm focus:ring-primary focus:border-primary h-10 px-3">
                                        <option value="0.20">Normal (20%)</option>
                                        <option value="0.10">Intermédiaire (10%)</option>
                                        <option value="0.055">Réduit (5.5%)</option>
                                        <option value="0">Exonéré (0%)</option>
                                    </select>
                                </div>
                                 <div>
                                    <label className="block text-sm font-medium text-muted-foreground mb-1">Conditions de paiement par défaut</label>
                                    <textarea name="defaultPaymentTerms" value={currentSettings.defaultPaymentTerms} onChange={handleChange} rows={2} className="w-full border border-border bg-card p-3 text-sm rounded-md shadow-sm focus:ring-primary focus:border-primary"></textarea>
                                </div>
                                 <div>
                                    <label className="block text-sm font-medium text-muted-foreground mb-1">Pied de page par défaut</label>
                                    <textarea name="defaultFooterText" value={currentSettings.defaultFooterText} onChange={handleChange} rows={3} className="w-full border border-border bg-card p-3 text-sm rounded-md shadow-sm focus:ring-primary focus:border-primary" placeholder="Pénalités de retard, ..."></textarea>
                                </div>
                             </div>
                        </Card>

                    </div>
                    <div>
                        <Card>
                             <h2 className="text-xl font-semibold mb-4">Logo & Apparence</h2>
                             <div className="space-y-6">
                                <div>
                                    <h3 className="text-md font-medium mb-2">Logo de l'entreprise</h3>
                                    <div className="flex flex-col items-center space-y-4">
                                        <div className="w-32 h-32 bg-secondary rounded-md flex items-center justify-center border border-dashed">
                                            {logoPreview ? <img src={logoPreview} alt="Aperçu du logo" className="max-w-full max-h-full object-contain" /> : <Image size={40} className="text-muted-foreground" />}
                                        </div>
                                        <input type="file" id="logo-upload" className="hidden" onChange={handleLogoChange} accept="image/*" />
                                        <label htmlFor="logo-upload" className="cursor-pointer inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2">
                                            Changer le logo
                                        </label>
                                    </div>
                                </div>
                                <div>
                                    <h3 className="text-md font-medium mb-2">Couleur d'accentuation</h3>
                                    <p className="text-sm text-muted-foreground mb-2">
                                        Cette couleur sera utilisée sur vos factures et devis.
                                    </p>
                                    <div className="flex items-center gap-2">
                                        <input
                                            type="color"
                                            name="accentColor"
                                            value={currentSettings.accentColor}
                                            onChange={handleChange}
                                            className="w-10 h-10 p-0 border-none rounded-md cursor-pointer bg-card"
                                        />
                                        <Input
                                            name="accentColor"
                                            value={currentSettings.accentColor}
                                            onChange={handleChange}
                                            className="flex-1"
                                        />
                                    </div>
                                </div>
                             </div>
                        </Card>
                    </div>
                </div>
                <div className="mt-8 flex justify-end items-center gap-4">
                    {isSaved && (
                        <div className="flex items-center gap-2 text-green-600 font-medium transition-opacity duration-300">
                           <CheckCircle size={16} />
                           <span>Enregistré !</span>
                        </div>
                    )}
                    <Button type="submit" disabled={!isFormValid}>Enregistrer les modifications</Button>
                </div>
            </form>
        </div>
    );
};

export default Settings;