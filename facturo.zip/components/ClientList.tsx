import React, { useState, useRef, useMemo, useEffect } from 'react';
import { Plus, Edit, MoreHorizontal, Upload, Search, FileSignature, FileText, Trash2, ArrowUp, ArrowDown, UserPlus } from 'lucide-react';
import { Client, Invoice, Quote, InvoiceStatus } from '../types';
import Card from './ui/Card';
import Button from './ui/Button';
import Modal from './ui/Modal';
import Input from './ui/Input';

interface ClientEditorProps {
    client: Client | null;
    onClose: () => void;
    onSave: (client: Client) => void;
}

export const ClientEditor: React.FC<ClientEditorProps> = ({ client, onClose, onSave }) => {
    const [editedClient, setEditedClient] = useState<Omit<Client, 'id'>>(
        client || {
            name: '',
            email: '',
            address: '',
            phone: '',
            notes: '',
        }
    );

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setEditedClient(prev => ({ ...prev, [name]: value }));
    };

    const isFormValid = editedClient.name.trim() !== '' && editedClient.email.trim() !== '' && editedClient.address.trim() !== '';

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!isFormValid) {
            alert("Veuillez remplir tous les champs.");
            return;
        }
        
        const clientToSave: Client = {
            id: client?.id || '', // ID will be set in App.tsx for new clients
            ...editedClient
        };
        onSave(clientToSave);
    };

    return (
        <Modal title={client ? 'Modifier le client' : 'Créer un client'} onClose={onClose}>
            <form onSubmit={handleSubmit} className="space-y-6">
                <Input
                    label="Nom du client"
                    name="name"
                    value={editedClient.name}
                    onChange={handleChange}
                    required
                />
                <Input
                    label="Email"
                    name="email"
                    type="email"
                    value={editedClient.email}
                    onChange={handleChange}
                    required
                />
                <Input
                    label="Numéro de téléphone (Optionnel)"
                    name="phone"
                    type="tel"
                    value={editedClient.phone || ''}
                    onChange={handleChange}
                />
                <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">Adresse</label>
                    <textarea
                        name="address"
                        value={editedClient.address}
                        onChange={handleChange}
                        rows={3}
                        className="w-full border-border bg-card p-3 text-sm rounded-md shadow-sm focus:ring-primary focus:border-primary"
                        required
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">Notes (interne)</label>
                    <textarea
                        name="notes"
                        value={editedClient.notes || ''}
                        onChange={handleChange}
                        rows={3}
                        placeholder="Informations spécifiques sur le client..."
                        className="w-full border-border bg-card p-3 text-sm rounded-md shadow-sm focus:ring-primary focus:border-primary"
                    />
                </div>
                <div className="flex justify-end space-x-3 pt-4">
                    <Button type="button" variant="outline" onClick={onClose}>Annuler</Button>
                    <Button type="submit" disabled={!isFormValid}>Enregistrer</Button>
                </div>
            </form>
        </Modal>
    );
};


interface ClientListProps {
    clients: Client[];
    invoices: Invoice[];
    quotes: Quote[];
    onViewClient: (client: Client) => void;
    onEditClient: (client: Client) => void;
    onCreateClient: () => void;
    onImportClients: (csvData: string) => void;
    onDeleteClient: (clientId: string) => void;
    onCreateInvoiceForClient: (clientId: string) => void;
    onCreateQuoteForClient: (clientId: string) => void;
}

type SortKey = 'name' | 'revenue' | 'invoiceCount';
type SortDirection = 'asc' | 'desc';

const ClientList: React.FC<ClientListProps> = (props) => {
    const { clients, invoices, onViewClient, onEditClient, onCreateClient, onImportClients, onDeleteClient, onCreateInvoiceForClient, onCreateQuoteForClient } = props;
    
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [sortConfig, setSortConfig] = useState<{ key: SortKey; direction: SortDirection } | null>({ key: 'name', direction: 'asc' });
    const [openMenuId, setOpenMenuId] = useState<string | null>(null);
    const menuRef = useRef<HTMLDivElement>(null);

    const clientStats = useMemo(() => {
        const statsMap = new Map<string, { revenue: number, invoiceCount: number }>();
        clients.forEach(c => statsMap.set(c.id, { revenue: 0, invoiceCount: 0 }));
        
        invoices.forEach(inv => {
            const clientStat = statsMap.get(inv.clientId);
            if (clientStat) {
                clientStat.invoiceCount += 1;
                if (inv.status === InvoiceStatus.Paid) {
                    const subtotal = inv.lineItems.reduce((acc, item) => acc + (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0), 0);
                    const totalTax = inv.lineItems.reduce((acc, item) => acc + ((Number(item.quantity) || 0) * (Number(item.unitPrice) || 0) * (Number(item.taxRate) || 0)), 0);
                    clientStat.revenue += subtotal + totalTax - (inv.discount || 0);
                }
            }
        });
        return statsMap;
    }, [clients, invoices]);
    
    const filteredAndSortedClients = useMemo(() => {
        let filtered = clients.filter(client =>
            client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            client.email.toLowerCase().includes(searchQuery.toLowerCase())
        );

        if (sortConfig !== null) {
            filtered.sort((a, b) => {
                const aStats = clientStats.get(a.id) || { revenue: 0, invoiceCount: 0 };
                const bStats = clientStats.get(b.id) || { revenue: 0, invoiceCount: 0 };
                
                let aValue, bValue;
                if (sortConfig.key === 'name') {
                    aValue = a.name;
                    bValue = b.name;
                } else if (sortConfig.key === 'revenue') {
                    aValue = aStats.revenue;
                    bValue = bStats.revenue;
                } else { // invoiceCount
                    aValue = aStats.invoiceCount;
                    bValue = bStats.invoiceCount;
                }

                if (aValue < bValue) {
                    return sortConfig.direction === 'asc' ? -1 : 1;
                }
                if (aValue > bValue) {
                    return sortConfig.direction === 'asc' ? 1 : -1;
                }
                return 0;
            });
        }

        return filtered;
    }, [clients, searchQuery, sortConfig, clientStats]);

    const requestSort = (key: SortKey) => {
        let direction: SortDirection = 'asc';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setSortConfig({ key, direction });
    };

    const handleImportClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const content = e.target?.result as string;
                onImportClients(content);
            };
            reader.readAsText(file, 'UTF-8');
        }
        event.target.value = '';
    };

    const getClientInitials = (name: string) => {
        const names = name.split(' ');
        if (names.length > 1) {
            return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
        }
        return name.substring(0, 2).toUpperCase();
    };
    
    const formatCurrency = (amount: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
                setOpenMenuId(null);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    const SortableHeader = ({ label, sortKey }: { label: string, sortKey: SortKey }) => {
        const isActive = sortConfig?.key === sortKey;
        return (
            <button className="flex items-center gap-1" onClick={() => requestSort(sortKey)}>
                {label}
                {isActive && (sortConfig?.direction === 'asc' ? <ArrowUp size={14} /> : <ArrowDown size={14} />)}
            </button>
        );
    };

    if (clients.length === 0 && searchQuery === '') {
        return (
            <div className="text-center py-20">
                <UserPlus size={48} className="mx-auto text-muted-foreground mb-4" />
                <h2 className="text-2xl font-semibold text-foreground">Aucun client pour le moment</h2>
                <p className="text-muted-foreground mt-2 mb-6">Commencez par ajouter votre premier client ou importez une liste existante.</p>
                <div className="flex justify-center gap-4">
                     <Button onClick={onCreateClient}>
                        <Plus size={16} className="mr-2" />
                        Nouveau Client
                    </Button>
                    <Button variant="outline" onClick={handleImportClick}>
                        <Upload size={16} className="mr-2" />
                        Importer CSV
                    </Button>
                    <input type="file" ref={fileInputRef} onChange={handleFileChange} accept=".csv" style={{ display: 'none' }} />
                </div>
            </div>
        )
    }

    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
                <h1 className="text-3xl font-bold text-primary">Clients</h1>
                <div className="flex w-full md:w-auto gap-2">
                    <div className="relative flex-grow">
                         <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                         <Input 
                            type="text"
                            placeholder="Rechercher un client..."
                            className="pl-9 w-full"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                         />
                    </div>
                     <Button onClick={onCreateClient} className="hidden sm:inline-flex">
                        <Plus size={16} className="mr-2" />
                        Nouveau Client
                    </Button>
                </div>
            </div>
             <Card>
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="border-b">
                            <tr>
                                <th className="p-4 font-semibold text-sm text-muted-foreground"><SortableHeader label="Nom" sortKey="name" /></th>
                                <th className="p-4 font-semibold text-sm text-muted-foreground"><SortableHeader label="Chiffre d'affaires" sortKey="revenue" /></th>
                                <th className="p-4 font-semibold text-sm text-muted-foreground"><SortableHeader label="Factures" sortKey="invoiceCount" /></th>
                                <th className="p-4 font-semibold text-sm text-muted-foreground text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredAndSortedClients.map(client => {
                                const stats = clientStats.get(client.id) || { revenue: 0, invoiceCount: 0 };
                                return (
                                <tr key={client.id} className="border-b last:border-b-0 hover:bg-secondary">
                                    <td className="p-4 font-medium">
                                        <div className="flex items-center gap-3">
                                            <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center font-semibold text-sm">
                                                {getClientInitials(client.name)}
                                            </div>
                                            <div>
                                                <button onClick={() => onViewClient(client)} className="text-primary hover:underline font-semibold text-left">
                                                    {client.name}
                                                </button>
                                                 <p className="text-sm text-muted-foreground">{client.email}</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="p-4 text-secondary-foreground font-medium">{formatCurrency(stats.revenue)}</td>
                                    <td className="p-4 text-secondary-foreground">{stats.invoiceCount}</td>
                                    <td className="p-4 text-right">
                                         <div className="flex items-center justify-end">
                                            <div className="relative" ref={openMenuId === client.id ? menuRef : null}>
                                                <button 
                                                    onMouseDown={(e) => e.stopPropagation()}
                                                    onClick={() => setOpenMenuId(openMenuId === client.id ? null : client.id)} 
                                                    className="p-2 text-muted-foreground hover:text-primary rounded-md hover:bg-muted">
                                                    <MoreHorizontal size={16} />
                                                </button>
                                                {openMenuId === client.id && (
                                                     <div className="absolute right-0 mt-2 w-48 bg-card rounded-md shadow-lg z-20 border border-border">
                                                         <ul className="py-1">
                                                            <li><button onClick={() => { onEditClient(client); setOpenMenuId(null); }} className="w-full text-left flex items-center px-4 py-2 text-sm hover:bg-secondary"><Edit size={14} className="mr-2"/> Modifier</button></li>
                                                            <li><button onClick={() => { onCreateInvoiceForClient(client.id); setOpenMenuId(null); }} className="w-full text-left flex items-center px-4 py-2 text-sm hover:bg-secondary"><FileText size={14} className="mr-2"/> Créer une facture</button></li>
                                                            <li><button onClick={() => { onCreateQuoteForClient(client.id); setOpenMenuId(null); }} className="w-full text-left flex items-center px-4 py-2 text-sm hover:bg-secondary"><FileSignature size={14} className="mr-2"/> Créer un devis</button></li>
                                                            <li className="border-t my-1"></li>
                                                            <li><button onClick={() => { onDeleteClient(client.id); setOpenMenuId(null); }} className="w-full text-left flex items-center px-4 py-2 text-sm text-red-600 hover:bg-red-50"><Trash2 size={14} className="mr-2"/> Supprimer</button></li>
                                                         </ul>
                                                     </div>
                                                )}
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            )})}
                        </tbody>
                    </table>
                     {filteredAndSortedClients.length === 0 && searchQuery !== '' && (
                         <div className="text-center p-8 text-muted-foreground">
                            Aucun client ne correspond à votre recherche.
                        </div>
                    )}
                </div>
            </Card>
        </div>
    );
};

export default ClientList;