import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
    label?: string;
}

const Input: React.FC<InputProps> = ({ label, id, className = '', ...props }) => {
    const inputId = id || props.name;
    return (
        <div>
            {label && <label htmlFor={inputId} className="block text-sm font-medium text-muted-foreground mb-1">{label}</label>}
            <input
                id={inputId}
                className={`flex h-10 w-full rounded-md border border-border bg-card px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 ${className}`}
                {...props}
            />
        </div>
    );
};

export default Input;