import React, { useState, useMemo } from 'react';
import { ArrowLeft, Edit, FileText, FileSignature, LucideProps, StickyNote } from 'lucide-react';
import { Client, Invoice, Quote, InvoiceStatus, QuoteStatus } from '../types';
import Card from './ui/Card';
import Button from './ui/Button';

interface ClientDetailProps {
    client: Client;
    invoices: Invoice[];
    quotes: Quote[];
    onBack: () => void;
    onEditClient: (client: Client) => void;
    calculateTotal: (doc: Invoice | Quote) => { netToPay: number };
    onEditInvoice: (invoice: Invoice) => void;
    onEditQuote: (quote: Quote) => void;
}

type Tab = 'invoices' | 'quotes';

const StatCard: React.FC<{title: string; value: string;}> = ({ title, value }) => (
    <Card>
        <p className="text-sm font-medium text-muted-foreground">{title}</p>
        <p className="text-2xl font-bold mt-1">{value}</p>
    </Card>
);

const getInvoiceStatusBadge = (status: InvoiceStatus) => {
    switch (status) {
        case InvoiceStatus.Paid:
            return <span className="bg-green-100 text-green-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Payée</span>;
        case InvoiceStatus.Sent:
            return <span className="bg-blue-100 text-blue-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Envoyée</span>;
        case InvoiceStatus.Overdue:
            return <span className="bg-red-100 text-red-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">En retard</span>;
        case InvoiceStatus.Draft:
            return <span className="bg-gray-100 text-gray-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Brouillon</span>;
        default: return null;
    }
};

const getQuoteStatusBadge = (status: QuoteStatus) => {
    switch (status) {
        case QuoteStatus.Accepted:
            return <span className="bg-green-100 text-green-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Accepté</span>;
        case QuoteStatus.Sent:
            return <span className="bg-blue-100 text-blue-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Envoyé</span>;
        case QuoteStatus.Declined:
            return <span className="bg-red-100 text-red-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Refusé</span>;
        case QuoteStatus.Draft:
            return <span className="bg-gray-100 text-gray-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Brouillon</span>;
        default: return null;
    }
};

const ClientDetail: React.FC<ClientDetailProps> = ({ client, invoices, quotes, onBack, onEditClient, calculateTotal, onEditInvoice, onEditQuote }) => {
    const [activeTab, setActiveTab] = useState<Tab>('invoices');
    const formatCurrency = (amount: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);

    const clientStats = useMemo(() => {
        const totalRevenue = invoices
            .filter(inv => inv.status === InvoiceStatus.Paid)
            .reduce((sum, inv) => sum + calculateTotal(inv).netToPay, 0);

        const outstandingAmount = invoices
            .filter(inv => inv.status === InvoiceStatus.Sent || inv.status === InvoiceStatus.Overdue)
            .reduce((sum, inv) => sum + calculateTotal(inv).netToPay, 0);
            
        return { totalRevenue, outstandingAmount };
    }, [invoices, calculateTotal]);
    
    const TabButton = ({ tab, label, icon }: { tab: Tab, label: string, icon: React.ReactElement<LucideProps> }) => (
         <button
            onClick={() => setActiveTab(tab)}
            className={`flex items-center px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                activeTab === tab 
                ? 'bg-accent text-accent-foreground'
                : 'text-muted-foreground hover:bg-muted'
            }`}
        >
            {React.cloneElement(icon, { size: 16, className: "mr-2" })}
            {label}
        </button>
    );

    return (
        <div className="space-y-8">
            <div>
                <Button variant="ghost" onClick={onBack} className="mb-4 -ml-4">
                    <ArrowLeft size={16} className="mr-2" />
                    Retour aux clients
                </Button>
                <div className="flex flex-col md:flex-row justify-between md:items-start gap-4">
                    <div>
                        <h1 className="text-3xl font-bold text-primary">{client.name}</h1>
                        <div className="flex items-center gap-x-4 gap-y-1 flex-wrap text-muted-foreground mt-1">
                            <span>{client.email}</span>
                            {client.phone && (
                                <>
                                    <span className="hidden sm:inline text-gray-300">•</span>
                                    <span>{client.phone}</span>
                                </>
                            )}
                        </div>
                    </div>
                    <Button variant="outline" onClick={() => onEditClient(client)} className="shrink-0">
                        <Edit size={16} className="mr-2" />
                        Modifier les informations
                    </Button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <StatCard title="Chiffre d'affaires" value={formatCurrency(clientStats.totalRevenue)} />
                <StatCard title="Montant dû" value={formatCurrency(clientStats.outstandingAmount)} />
                 <Card>
                    <p className="text-sm font-medium text-muted-foreground">Contact</p>
                    <p className="font-semibold mt-1 whitespace-pre-line">{client.address}</p>
                </Card>
            </div>
            
            {client.notes && (
                <Card>
                    <h3 className="text-md font-semibold flex items-center mb-2"><StickyNote size={16} className="mr-2"/> Notes</h3>
                    <p className="text-sm text-secondary-foreground whitespace-pre-wrap">{client.notes}</p>
                </Card>
            )}

            <div>
                <div className="border-b border-border mb-4">
                    <nav className="flex space-x-2" aria-label="Tabs">
                       <TabButton tab="invoices" label={`Factures (${invoices.length})`} icon={<FileText />} />
                       <TabButton tab="quotes" label={`Devis (${quotes.length})`} icon={<FileSignature />} />
                    </nav>
                </div>

                <Card>
                    {activeTab === 'invoices' && (
                        <div>
                            {invoices.length > 0 ? (
                                <div className="overflow-x-auto">
                                    <table className="w-full text-left">
                                        <thead className="border-b">
                                            <tr>
                                                <th className="p-4 font-semibold text-sm text-muted-foreground">Numéro</th>
                                                <th className="p-4 font-semibold text-sm text-muted-foreground">Date</th>
                                                <th className="p-4 font-semibold text-sm text-muted-foreground">Montant</th>
                                                <th className="p-4 font-semibold text-sm text-muted-foreground">Statut</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {invoices.map(inv => (
                                                <tr key={inv.id} className="border-b last:border-b-0 hover:bg-secondary cursor-pointer" onClick={() => onEditInvoice(inv)}>
                                                    <td className="p-4 font-medium">{inv.invoiceNumber}</td>
                                                    <td className="p-4 text-secondary-foreground">{new Date(inv.issueDate).toLocaleDateString('fr-FR')}</td>
                                                    <td className="p-4 text-secondary-foreground">{formatCurrency(calculateTotal(inv).netToPay)}</td>
                                                    <td className="p-4">{getInvoiceStatusBadge(inv.status)}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            ) : (
                                <p className="text-center text-muted-foreground py-8">Aucune facture pour ce client.</p>
                            )}
                        </div>
                    )}
                     {activeTab === 'quotes' && (
                        <div>
                             {quotes.length > 0 ? (
                                <div className="overflow-x-auto">
                                    <table className="w-full text-left">
                                        <thead className="border-b">
                                            <tr>
                                                <th className="p-4 font-semibold text-sm text-muted-foreground">Numéro</th>
                                                <th className="p-4 font-semibold text-sm text-muted-foreground">Date</th>
                                                <th className="p-4 font-semibold text-sm text-muted-foreground">Montant</th>
                                                <th className="p-4 font-semibold text-sm text-muted-foreground">Statut</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {quotes.map(q => (
                                                <tr key={q.id} className="border-b last:border-b-0 hover:bg-secondary cursor-pointer" onClick={() => onEditQuote(q)}>
                                                    <td className="p-4 font-medium">{q.quoteNumber}</td>
                                                    <td className="p-4 text-secondary-foreground">{new Date(q.issueDate).toLocaleDateString('fr-FR')}</td>
                                                    <td className="p-4 text-secondary-foreground">{formatCurrency(calculateTotal(q).netToPay)}</td>
                                                    <td className="p-4">{getQuoteStatusBadge(q.status)}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            ) : (
                                <p className="text-center text-muted-foreground py-8">Aucun devis pour ce client.</p>
                            )}
                        </div>
                    )}
                </Card>
            </div>
        </div>
    );
};

export default ClientDetail;