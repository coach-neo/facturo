import React, { useState } from 'react';

interface LoginPageProps {
    onLogin: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
    const [mode, setMode] = useState<'login' | 'signup'>('login');

    const handleSubmit = (event: React.FormEvent) => {
        event.preventDefault();
        onLogin();
    };

    const toggleMode = () => {
        setMode(prevMode => prevMode === 'login' ? 'signup' : 'login');
    };

    return (
        <div className="container">
            <div className="logo">🧾 Facturo</div>
            <h1>{mode === 'login' ? 'Bienvenue sur Facturo' : 'Créez votre compte'}</h1>
            <div className="welcome">
                {mode === 'login' ? (
                    <>
                        Ma petite entreprise <span>ne connaît pas la crise !</span>
                        <br />
                        Gérez vos clients et factures en toute simplicité… et avec le sourire 😄
                    </>
                ) : (
                    "Rejoignez-nous et simplifiez votre facturation dès aujourd'hui."
                )}
            </div>
            <form autoComplete="off" onSubmit={handleSubmit}>
                <input type="text" name="username" placeholder="Nom d'utilisateur" required />
                <input type="password" name="password" placeholder="Mot de passe" required />
                {mode === 'signup' && (
                    <input type="password" name="confirmPassword" placeholder="Confirmez le mot de passe" required />
                )}
                <br />
                <button type="submit">{mode === 'login' ? 'Connexion sécurisée' : "S'inscrire"}</button>
            </form>
            <div className="toggle-mode-container">
                {mode === 'login' ? (
                    <>
                        Pas encore de compte ?{' '}
                        <button type="button" onClick={toggleMode} className="toggle-button">
                            Inscrivez-vous
                        </button>
                    </>
                ) : (
                    <>
                        Déjà un compte ?{' '}
                        <button type="button" onClick={toggleMode} className="toggle-button">
                            Connectez-vous
                        </button>
                    </>
                )}
            </div>
        </div>
    );
};

export default LoginPage;