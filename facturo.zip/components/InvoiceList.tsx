import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Plus, Edit, MoreHorizontal, Download, Send, ArrowUp, ArrowDown } from 'lucide-react';
import { Invoice, Client, InvoiceStatus } from '../types';
import Card from './ui/Card';
import Button from './ui/Button';

interface InvoiceListProps {
    invoices: Invoice[];
    clients: Client[];
    onEditInvoice: (invoice: Invoice) => void;
    onCreateInvoice: () => void;
    onDownloadInvoice: (invoice: Invoice) => void;
    onSendInvoice: (invoice: Invoice) => void;
}

const getStatusBadge = (status: InvoiceStatus) => {
    switch (status) {
        case InvoiceStatus.Paid:
            return <span className="bg-green-100 text-green-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Payée</span>;
        case InvoiceStatus.Sent:
            return <span className="bg-blue-100 text-blue-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Envoyée</span>;
        case InvoiceStatus.Overdue:
            return <span className="bg-red-100 text-red-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">En retard</span>;
        case InvoiceStatus.Draft:
            return <span className="bg-gray-100 text-gray-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Brouillon</span>;
        default:
            return null;
    }
};

const SummaryCard: React.FC<{ title: string; value: string; className?: string }> = ({ title, value, className }) => (
    <div className={`bg-card p-4 rounded-lg border ${className}`}>
        <p className="text-sm font-medium text-muted-foreground">{title}</p>
        <p className="text-xl font-bold mt-1">{value}</p>
    </div>
);


type SortKey = 'invoiceNumber' | 'clientName' | 'issueDate' | 'total' | 'status';
type SortDirection = 'asc' | 'desc';

const InvoiceList: React.FC<InvoiceListProps> = ({ invoices, clients, onEditInvoice, onCreateInvoice, onDownloadInvoice, onSendInvoice }) => {
    const [openMenuId, setOpenMenuId] = useState<string | null>(null);
    const [filterStatus, setFilterStatus] = useState<InvoiceStatus | 'All'>('All');
    const [sortConfig, setSortConfig] = useState<{ key: SortKey; direction: SortDirection } | null>({ key: 'issueDate', direction: 'desc' });
    const menuRef = useRef<HTMLDivElement>(null);
    
    const getClientName = (clientId: string) => clients.find(c => c.id === clientId)?.name || 'Client inconnu';
    const formatCurrency = (amount: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);

    const calculateTotal = (invoice: Invoice) => {
        const subtotal = invoice.lineItems.reduce((acc, item) => acc + (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0), 0);
        const totalTax = invoice.lineItems.reduce((acc, item) => acc + ((Number(item.quantity) || 0) * (Number(item.unitPrice) || 0) * (Number(item.taxRate) || 0)), 0);
        return subtotal + totalTax - (invoice.discount || 0);
    };

    const processedInvoices = useMemo(() => {
        let filteredInvoices = [...invoices];

        if (filterStatus !== 'All') {
            filteredInvoices = filteredInvoices.filter(q => q.status === filterStatus);
        }

        if (sortConfig !== null) {
            filteredInvoices.sort((a, b) => {
                let aValue: string | number;
                let bValue: string | number;

                switch (sortConfig.key) {
                    case 'clientName':
                        aValue = getClientName(a.clientId);
                        bValue = getClientName(b.clientId);
                        break;
                    case 'total':
                        aValue = calculateTotal(a);
                        bValue = calculateTotal(b);
                        break;
                    default:
                        aValue = a[sortConfig.key];
                        bValue = b[sortConfig.key];
                        break;
                }
                
                if (aValue < bValue) {
                    return sortConfig.direction === 'asc' ? -1 : 1;
                }
                if (aValue > bValue) {
                    return sortConfig.direction === 'asc' ? 1 : -1;
                }
                return 0;
            });
        }
        
        return filteredInvoices;
    }, [invoices, filterStatus, sortConfig, clients]);
    
    const summaryStats = useMemo(() => {
        const totalInvoiced = processedInvoices.reduce((sum, inv) => sum + calculateTotal(inv), 0);
        const totalPaid = processedInvoices
            .filter(inv => inv.status === InvoiceStatus.Paid)
            .reduce((sum, inv) => sum + calculateTotal(inv), 0);
        const totalOverdue = processedInvoices
            .filter(inv => inv.status === InvoiceStatus.Overdue)
            .reduce((sum, inv) => sum + calculateTotal(inv), 0);
        
        return { totalInvoiced, totalPaid, totalOverdue };
    }, [processedInvoices]);


    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
                setOpenMenuId(null);
            }
        };

        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);
    
    const requestSort = (key: SortKey) => {
        let direction: SortDirection = 'asc';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setSortConfig({ key, direction });
    };

    const SortableHeader = ({ label, sortKey }: { label: string, sortKey: SortKey }) => {
        const isActive = sortConfig?.key === sortKey;
        return (
            <button className="flex items-center gap-1 font-semibold text-sm text-muted-foreground" onClick={() => requestSort(sortKey)}>
                {label}
                {isActive && (sortConfig?.direction === 'asc' ? <ArrowUp size={14} /> : <ArrowDown size={14} />)}
            </button>
        );
    };


    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-3xl font-bold">Factures</h1>
                <Button onClick={onCreateInvoice}>
                    <Plus size={16} className="mr-2" />
                    Créer une facture
                </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <SummaryCard title="Total Facturé (TTC)" value={formatCurrency(summaryStats.totalInvoiced)} />
                <SummaryCard title="Total Encaissé" value={formatCurrency(summaryStats.totalPaid)} className="border-green-500/50" />
                <SummaryCard title="En Retard" value={formatCurrency(summaryStats.totalOverdue)} className="border-red-500/50" />
            </div>

            <Card className="bg-card">
                 <div className="p-4 border-b">
                    <div className="flex items-center gap-2 flex-wrap">
                        {(['All', ...Object.values(InvoiceStatus)] as const).map(status => (
                            <button
                                key={status}
                                onClick={() => setFilterStatus(status)}
                                className={`px-3 py-1 text-sm rounded-full transition-colors ${
                                    filterStatus === status
                                        ? 'bg-accent text-accent-foreground font-semibold'
                                        : 'bg-muted text-muted-foreground hover:bg-secondary'
                                }`}
                            >
                                {status === 'All' ? 'Toutes' : status}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="border-b border-border">
                            <tr>
                                <th className="p-4"><SortableHeader label="Numéro" sortKey="invoiceNumber" /></th>
                                <th className="p-4"><SortableHeader label="Client" sortKey="clientName" /></th>
                                <th className="p-4"><SortableHeader label="Date d'émission" sortKey="issueDate" /></th>
                                <th className="p-4"><SortableHeader label="Montant" sortKey="total" /></th>
                                <th className="p-4"><SortableHeader label="Statut" sortKey="status" /></th>
                                <th className="p-4 font-semibold text-sm text-muted-foreground">Moyen de paiement</th>
                                <th className="p-4 font-semibold text-sm text-muted-foreground text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {processedInvoices.map(invoice => (
                                <tr key={invoice.id} className="border-b border-border hover:bg-secondary">
                                    <td className="p-4 font-medium">{invoice.invoiceNumber}</td>
                                    <td className="p-4 text-secondary-foreground">{getClientName(invoice.clientId)}</td>
                                    <td className="p-4 text-secondary-foreground">{new Date(invoice.issueDate).toLocaleDateString('fr-FR')}</td>
                                    <td className="p-4 text-secondary-foreground">{formatCurrency(calculateTotal(invoice))}</td>
                                    <td className="p-4">{getStatusBadge(invoice.status)}</td>
                                    <td className="p-4 text-secondary-foreground">{invoice.status === InvoiceStatus.Paid ? invoice.paymentMethod : '—'}</td>
                                    <td className="p-4">
                                         <div className="flex items-center justify-end space-x-1">
                                            <button onClick={() => onEditInvoice(invoice)} className="p-2 text-muted-foreground hover:text-primary rounded-md hover:bg-muted">
                                                <Edit size={16} />
                                            </button>
                                            <div className="relative" ref={openMenuId === invoice.id ? menuRef : null}>
                                                <button 
                                                    onMouseDown={(e) => e.stopPropagation()}
                                                    onClick={() => setOpenMenuId(openMenuId === invoice.id ? null : invoice.id)} 
                                                    className="p-2 text-muted-foreground hover:text-primary rounded-md hover:bg-muted">
                                                    <MoreHorizontal size={16} />
                                                </button>
                                                {openMenuId === invoice.id && (
                                                    <div className="absolute right-0 mt-2 w-48 bg-card rounded-md shadow-lg z-20 border border-border">
                                                        <ul className="py-1">
                                                            <li>
                                                                <button
                                                                    onClick={() => { onDownloadInvoice(invoice); setOpenMenuId(null); }}
                                                                    className="w-full text-left flex items-center px-4 py-2 text-sm text-foreground hover:bg-secondary"
                                                                >
                                                                    <Download size={14} className="mr-2" />
                                                                    Télécharger
                                                                </button>
                                                            </li>
                                                            <li>
                                                                <button
                                                                    onClick={() => { onSendInvoice(invoice); setOpenMenuId(null); }}
                                                                    className="w-full text-left flex items-center px-4 py-2 text-sm text-foreground hover:bg-secondary"
                                                                >
                                                                    <Send size={14} className="mr-2" />
                                                                    Envoyer
                                                                </button>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                     {processedInvoices.length === 0 && (
                         <div className="text-center p-8 text-muted-foreground">
                            Aucune facture ne correspond à vos filtres.
                        </div>
                    )}
                </div>
            </Card>
        </div>
    );
};

export default InvoiceList;
