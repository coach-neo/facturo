import React, { useState, useEffect } from 'react';
import { Send } from 'lucide-react';
import { Invoice, Quote, Client, Settings } from '../types';
import Modal from './ui/Modal';
import Input from './ui/Input';
import Button from './ui/Button';

interface SendModalProps {
    documentInfo: {
        doc: Invoice | Quote;
        client: Client;
        type: 'invoice' | 'quote';
    };
    settings: Settings;
    onClose: () => void;
    onConfirm: (subject: string, body: string) => void;
}

const SendModal: React.FC<SendModalProps> = ({ documentInfo, settings, onClose, onConfirm }) => {
    const { doc, client, type } = documentInfo;
    const docType = type === 'invoice' ? 'facture' : 'devis';
    const docNumber = 'invoiceNumber' in doc ? doc.invoiceNumber : doc.quoteNumber;

    const [subject, setSubject] = useState('');
    const [body, setBody] = useState('');

    useEffect(() => {
        setSubject(`Votre ${docType} n°${docNumber} de la part de ${settings.companyName}`);
        
        const senderName = settings.isSoleProprietorship 
            ? `${settings.companyOwnerFirstName} ${settings.companyOwnerLastName}` 
            : settings.companyName;

        const defaultBody = `Bonjour ${client.name},\n\nVeuillez trouver ci-joint votre ${docType} n°${docNumber}.\n\nN'hésitez pas à me contacter pour toute question.\n\nCordialement,\n\n${senderName}`;
        setBody(defaultBody);
    }, [doc, client, type, docType, docNumber, settings]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onConfirm(subject, body);
    };

    return (
        <Modal title={`Envoyer le ${docType} par email`} onClose={onClose}>
            <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">À</label>
                    <Input
                        type="email"
                        value={client.email}
                        readOnly
                        className="bg-secondary"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">Sujet</label>
                    <Input
                        value={subject}
                        onChange={(e) => setSubject(e.target.value)}
                        required
                    />
                </div>
                 <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">Message</label>
                    <textarea
                        value={body}
                        onChange={(e) => setBody(e.target.value)}
                        rows={10}
                        className="w-full border-border bg-card p-3 text-sm rounded-md shadow-sm focus:ring-primary focus:border-primary"
                        required
                    />
                </div>

                <div className="flex justify-end space-x-3 pt-4">
                    <Button type="button" variant="outline" onClick={onClose}>Annuler</Button>
                    <Button type="submit">
                        <Send size={16} className="mr-2" />
                        Envoyer
                    </Button>
                </div>
            </form>
        </Modal>
    );
};

export default SendModal;
