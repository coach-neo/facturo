import React, { useState, useCallback, useEffect } from 'react';
import { Page, Client, Invoice, Quote, Settings as AppSettings, InvoiceStatus, LineItem, QuoteStatus } from './types';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import InvoiceList from './components/InvoiceList';
import InvoiceEditor from './components/InvoiceEditor';
import ClientList, { ClientEditor } from './components/ClientList';
import ClientDetail from './components/ClientDetail';
import Settings from './components/Settings';
import { useMockData } from './hooks/useMockData';
import QuoteList from './components/QuoteList';
import QuoteEditor from './components/QuoteEditor';
import Reports from './components/Reports';
import LoginPage from './components/LoginPage';
import SendModal from './components/SendModal';


const App: React.FC = () => {
    const { clients, setClients, invoices, setInvoices, quotes, setQuotes, settings, setSettings } = useMockData();
    const [currentPage, setCurrentPage] = useState<Page>(Page.Dashboard);
    
    // Editor states
    const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);
    const [isEditorOpen, setIsEditorOpen] = useState<boolean>(false);

    const [editingQuote, setEditingQuote] = useState<Quote | null>(null);
    const [isQuoteEditorOpen, setIsQuoteEditorOpen] = useState<boolean>(false);
    
    const [editingClient, setEditingClient] = useState<Client | null>(null);
    const [isClientEditorOpen, setIsClientEditorOpen] = useState<boolean>(false);

    // Detail view state
    const [viewingClient, setViewingClient] = useState<Client | null>(null);
    
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

    // Authentication state
    const [isLoggedIn, setIsLoggedIn] = useState(() => !!localStorage.getItem('neofact-isLoggedIn'));
    
    // Sending state
    const [documentToSend, setDocumentToSend] = useState<{ doc: Invoice | Quote; client: Client; type: 'invoice' | 'quote' } | null>(null);


    useEffect(() => {
        const body = document.body;
        if (!isLoggedIn) {
            body.classList.add('login-page-active');
        } else {
            body.classList.remove('login-page-active');
        }
        return () => {
            body.classList.remove('login-page-active');
        };
    }, [isLoggedIn]);

    const handleLogin = () => {
        localStorage.setItem('neofact-isLoggedIn', 'true');
        setIsLoggedIn(true);
    };

    const handleLogout = () => {
        localStorage.removeItem('neofact-isLoggedIn');
        setIsLoggedIn(false);
    };


    const handleOpenEditor = (invoice: Invoice | null) => {
        setEditingInvoice(invoice);
        setIsEditorOpen(true);
    };

    const handleSaveInvoice = (invoiceToSave: Invoice) => {
        if (editingInvoice && invoiceToSave.id) {
            setInvoices(invoices.map(inv => inv.id === invoiceToSave.id ? invoiceToSave : inv));
        } else {
            const newInvoiceNumber = `${settings.invoicePrefix}${String(settings.nextInvoiceNumber).padStart(3, '0')}`;
            const newInvoice = { 
                ...invoiceToSave, 
                id: `inv_${Date.now()}`, 
                invoiceNumber: newInvoiceNumber 
            };
            setInvoices([...invoices, newInvoice]);
            setSettings(prev => ({ ...prev, nextInvoiceNumber: prev.nextInvoiceNumber + 1 }));
        }
        setIsEditorOpen(false);
        setEditingInvoice(null);
    };
    
    const handleCreateInvoiceForClient = (clientId: string) => {
        const newDraftInvoice = {
            clientId: clientId,
            issueDate: new Date().toISOString().split('T')[0],
            dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            lineItems: [{ id: `li_${Date.now()}`, description: '', quantity: 1, unitPrice: 0, taxRate: settings.defaultTaxRate }],
            status: InvoiceStatus.Draft,
            discount: 0,
            acompte: 0,
        };
        handleOpenEditor(newDraftInvoice as Invoice);
        setCurrentPage(Page.Invoices);
    };

    const handleOpenQuoteEditor = (quote: Quote | null) => {
        setEditingQuote(quote);
        setIsQuoteEditorOpen(true);
    };

    const handleSaveQuote = (quoteToSave: Quote) => {
        if (editingQuote && quoteToSave.id) {
            setQuotes(quotes.map(q => q.id === quoteToSave.id ? quoteToSave : q));
        } else {
            const newQuoteNumber = `${settings.quotePrefix}${String(settings.nextQuoteNumber).padStart(3, '0')}`;
            const newQuote = { 
                ...quoteToSave, 
                id: `quo_${Date.now()}`, 
                quoteNumber: newQuoteNumber 
            };
            setQuotes([...quotes, newQuote]);
            setSettings(prev => ({ ...prev, nextQuoteNumber: prev.nextQuoteNumber + 1 }));
        }
        setIsQuoteEditorOpen(false);
        setEditingQuote(null);
    };

    const handleCreateQuoteForClient = (clientId: string) => {
        const newDraftQuote = {
            clientId: clientId,
            issueDate: new Date().toISOString().split('T')[0],
            expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            lineItems: [{ id: `li_${Date.now()}`, description: '', quantity: 1, unitPrice: 0, taxRate: settings.defaultTaxRate }],
            status: QuoteStatus.Draft,
            discount: 0,
            acompte: 0,
        };
        handleOpenQuoteEditor(newDraftQuote as Quote);
        setCurrentPage(Page.Quotes);
    };


    const handleOpenClientEditor = (client: Client | null) => {
        setEditingClient(client);
        setIsClientEditorOpen(true);
    };

    const handleSaveClient = (clientToSave: Client) => {
        const isEditing = clients.some(c => c.id === clientToSave.id);
        if (isEditing) {
            setClients(clients.map(c => c.id === clientToSave.id ? clientToSave : c));
            if (viewingClient && viewingClient.id === clientToSave.id) {
                setViewingClient(clientToSave);
            }
        } else {
            setClients([...clients, { ...clientToSave, id: `cli_${Date.now()}` }]);
        }
        setIsClientEditorOpen(false);
        setEditingClient(null);
    };
    
    const handleDeleteClient = (clientId: string) => {
        if (window.confirm("Êtes-vous sûr de vouloir supprimer ce client ? Cette action est irréversible.")) {
            setClients(clients.filter(c => c.id !== clientId));
            // Optional: Also handle what happens to invoices/quotes of this client
        }
    };

    const handleImportClients = (csvData: string) => {
        try {
            const lines = csvData.trim().split('\n');
            if (lines.length <= 1 && lines[0].toLowerCase().includes('name')) {
                alert("Le fichier CSV est vide ou ne contient que l'en-tête.");
                return;
            }

            // Assume first row is header if it contains 'name', 'email', 'address'
            if (lines[0] && lines[0].toLowerCase().includes('name')) {
                lines.shift();
            }

            const newClients: Client[] = lines
                .map((line, index) => {
                    const [name, email, address, phone, notes] = line.split(',');
                    if (name && email && address) {
                        return {
                            id: `cli_import_${Date.now()}_${index}`,
                            name: name.trim().replace(/"/g, ''),
                            email: email.trim().replace(/"/g, ''),
                            address: address.trim().replace(/"/g, ''),
                            phone: phone ? phone.trim().replace(/"/g, '') : undefined,
                            notes: notes ? notes.trim().replace(/"/g, '') : undefined,
                        };
                    }
                    return null;
                })
                .filter((client): client is NonNullable<typeof client> => client !== null);

            if (newClients.length > 0) {
                setClients(prevClients => [...prevClients, ...newClients]);
                alert(`${newClients.length} clients importés avec succès !`);
            } else {
                alert("Aucun client valide n'a été trouvé dans le fichier. Assurez-vous que le format est 'nom,email,adresse,numero_de_telephone,notes' (téléphone et notes sont optionnels).");
            }
        } catch (error) {
            console.error("Erreur lors de l'importation du CSV:", error);
            alert("Une erreur est survenue lors de la lecture du fichier CSV. Veuillez vérifier son format.");
        }
    };


    const handleViewClient = (client: Client) => {
        setViewingClient(client);
        setCurrentPage(Page.Clients);
    };

    const handleSaveSettings = (newSettings: AppSettings) => {
        setSettings(newSettings);
    };

    const handleSearchSelect = (item: Client | Invoice) => {
        if ('invoiceNumber' in item) { // It's an Invoice
          setCurrentPage(Page.Invoices);
          handleOpenEditor(item);
        } else { // It's a Client
          setCurrentPage(Page.Clients);
          handleViewClient(item);
        }
    };

    const formatCurrency = (amount: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);
    const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
    
    const calculateLineItemTotal = (item: LineItem) => {
        return (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0);
    };
    
    const calculateTotals = (doc: Invoice | Quote) => {
        const subtotal = doc.lineItems.reduce((acc, item) => acc + calculateLineItemTotal(item), 0);
        const totalTax = doc.lineItems.reduce((acc, item) => acc + (calculateLineItemTotal(item) * (Number(item.taxRate) || 0)), 0);
        const total = subtotal + totalTax;
        const acompte = doc.acompte || 0;
        const netToPay = total - (doc.discount || 0);
        const finalAmount = netToPay - acompte;
        return { subtotal, totalTax, total, discount: doc.discount || 0, acompte, netToPay, finalAmount };
    };

    const generateInvoiceHTML = (invoice: Invoice, client: Client, settings: AppSettings): string => {
        const { subtotal, totalTax, total, discount, acompte, finalAmount } = calculateTotals(invoice);
        
        const isSoleProprietorshipLike = settings.legalStatus.includes('Entreprise Individuelle') || settings.legalStatus.includes('Micro-entreprise') || settings.legalStatus.includes('EIRL');

        const logoHTML = settings.logoUrl 
            ? `<img src="${settings.logoUrl}" alt="Logo" style="max-height: 80px; max-width: 200px;">` 
            : `<h2 style="font-size: 1.5rem; font-weight: 700; color: #111827; margin: 0;">${settings.companyName}</h2>`;
        
        const emitterBlock = isSoleProprietorshipLike
            ? `<p style="font-weight: 700; font-size: 1rem; margin: 0;">${settings.companyOwnerFirstName} ${settings.companyOwnerLastName}</p>
               ${settings.companyName ? `<p style="font-size: 0.8rem; margin: 2px 0 8px 0; color: #4b5563;"><em>(Nom commercial: ${settings.companyName})</em></p>` : '<div style="height: 8px;"></div>'}
               <p style="font-size: 0.875rem; margin: 2px 0; line-height: 1.4;">${settings.companyAddress.replace(/\n/g, '<br>')}</p>
               <p style="font-size: 0.75rem; margin-top: 8px; color: #6b7280;">${settings.legalInfo}</p>
              `
            : `<p style="font-weight: 700; font-size: 1rem; margin: 0 0 4px 0;">${settings.companyName}</p>
               <p style="font-size: 0.8rem; color: #4b5563; margin: 0 0 8px 0;">${settings.legalStatus}</p>
               <p style="font-size: 0.875rem; margin: 2px 0; line-height: 1.4;">${settings.companyAddress.replace(/\n/g, '<br>')}</p>
               <p style="font-size: 0.75rem; margin-top: 8px; color: #6b7280;">${settings.legalInfo}</p>
              `;

        const lineItemsHTML = invoice.lineItems.map(item => {
            const lineTotal = (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0);
            return `
                <tr style="border-bottom: 1px solid #e5e7eb;">
                    <td style="padding: 10px 0; text-align: left;">${item.description}</td>
                    <td style="padding: 10px 0; text-align: right;">${formatCurrency(Number(item.unitPrice))}</td>
                    <td style="padding: 10px 0; text-align: center;">${item.quantity}</td>
                    <td style="padding: 10px 0; text-align: right;">${formatCurrency(lineTotal)}</td>
                </tr>
            `;
        }).join('');

        const paymentLinkHTML = settings.paymentLink ? `
            <div style="margin-top: 1rem; text-align: center;">
                <a href="${settings.paymentLink}" target="_blank" rel="noopener noreferrer" style="display: inline-block; background-color: ${settings.accentColor}; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: 600; font-size: 0.9rem;">Payer en ligne</a>
            </div>
        ` : '';

        return `
            <!DOCTYPE html>
            <html lang="fr">
            <head>
                <meta charset="UTF-8">
                <title>Facture ${invoice.invoiceNumber}</title>
                <link rel="preconnect" href="https://fonts.googleapis.com">
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
                <style>
                    * { box-sizing: border-box; }
                    body { font-family: 'Inter', sans-serif; background-color: #f9fafb; margin: 0; padding: 1rem; color: #374151; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
                    .invoice-container { max-width: 800px; margin: 2rem auto; background: white; border: 1px solid #e5e7eb; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -2px rgba(0,0,0,0.1); }
                    .invoice-content { padding: 3rem; }
                    .info-label { color: #6b7280; font-size: 0.8rem; margin-bottom: 2px; }
                    .info-data { font-weight: 500; }
                    table { width: 100%; border-collapse: collapse; margin: 2rem 0; }
                    table th { padding: 10px 0; text-align: left; font-weight: 600; font-size: 0.8rem; letter-spacing: 0.5px; text-transform: uppercase; color: #111827; border-bottom: 2px solid ${settings.accentColor}; }
                    table td { font-size: 0.9rem; }
                    .total-summary-label { color: #4b5563; }
                    .total-summary-value { font-weight: 600; }
                    .net-payable { background-color: ${settings.accentColor}1A; border: 1px solid ${settings.accentColor}; padding: 1rem; margin-top: 1rem; border-radius: 8px; }
                    .net-payable .label { font-weight: 700; font-size: 1.1rem; color: #111827; }
                    .net-payable .value { font-weight: 700; font-size: 1.25rem; color: ${settings.accentColor}; }
                    footer { padding: 2rem 3rem; border-top: 1px solid #e5e7eb; font-size: 0.8rem; color: #6b7280; }
                    @media print { body { background-color: white; padding: 0; margin: 0; } .invoice-container { margin: 0; box-shadow: none; border: none; width: 100%; } .no-print { display: none !important; } @page { size: A4; margin: 0; } body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
                </style>
            </head>
            <body>
                <div class="invoice-container">
                    <main class="invoice-content">
                        <header style="display: flex; justify-content: space-between; align-items: flex-start; padding-bottom: 2rem; border-bottom: 1px solid #e5e7eb;">
                            <div style="flex: 1;">${logoHTML}</div>
                            <div style="text-align: right;">
                                <h1 style="font-size: 2.5rem; font-weight: 700; color: ${settings.accentColor}; margin: 0;">FACTURE</h1>
                                <p class="info-data" style="margin: 0;">${invoice.invoiceNumber}</p>
                            </div>
                        </header>
                        <section style="display: flex; justify-content: space-between; margin-top: 2rem;">
                            <div style="width: 48%;">
                                <p class="info-label" style="text-transform: uppercase; font-weight: 600;">DE</p>
                                ${emitterBlock}
                            </div>
                            <div style="width: 48%;">
                                <div style="margin-bottom: 1.5rem;">
                                    <p class="info-label">Date d'émission</p>
                                    <p class="info-data">${formatDate(invoice.issueDate)}</p>
                                </div>
                                <div>
                                    <p class="info-label" style="text-transform: uppercase; font-weight: 600;">POUR</p>
                                    <p class="info-data" style="font-size: 1rem; font-weight: 600; margin-bottom: 4px;">${client.name}</p>
                                    <p style="font-size: 0.875rem; margin: 2px 0; line-height: 1.4;">${client.address.replace(/\n/g, '<br>')}</p>
                                    <p style="font-size: 0.875rem; margin: 2px 0;">${client.email}</p>
                                </div>
                            </div>
                        </section>
                        <table>
                            <thead>
                                <tr>
                                    <th>Description</th>
                                    <th style="text-align: right;">Prix unitaire</th>
                                    <th style="text-align: center;">Quantité</th>
                                    <th style="text-align: right;">Total</th>
                                </tr>
                            </thead>
                            <tbody>${lineItemsHTML}</tbody>
                        </table>
                        <div style="display: flex; justify-content: flex-end; align-items: flex-start;">
                            <div style="width: 50%; max-width: 350px; font-size: 0.9rem;">
                                <div style="display: flex; justify-content: space-between; padding: 6px 0;">
                                    <span class="total-summary-label">TOTAL HT</span><span class="total-summary-value">${formatCurrency(subtotal)}</span>
                                </div>
                                <div style="display: flex; justify-content: space-between; padding: 6px 0;">
                                    <span class="total-summary-label">TVA</span><span class="total-summary-value">${formatCurrency(totalTax)}</span>
                                </div>
                                <div style="display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid #e5e7eb;">
                                    <span class="total-summary-label">TOTAL TTC</span><span class="total-summary-value">${formatCurrency(total)}</span>
                                </div>
                                ${discount > 0 ? `<div style="display: flex; justify-content: space-between; padding: 6px 0;">
                                    <span class="total-summary-label">REMISE</span><span class="total-summary-value">-${formatCurrency(discount)}</span>
                                </div>` : ''}
                                ${acompte > 0 ? `<div style="display: flex; justify-content: space-between; padding: 6px 0;">
                                    <span class="total-summary-label">ACOMPTE PAYÉ</span><span class="total-summary-value">-${formatCurrency(acompte)}</span>
                                </div>` : ''}
                                <div class="net-payable">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <span class="label">NET À PAYER</span>
                                        <span class="value">${formatCurrency(finalAmount)}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div style="margin-top: 3rem; padding-top: 1.5rem; border-top: 1px solid #e5e7eb;">
                            <h3 style="font-size: 1rem; font-weight: 600; margin: 0 0 1rem 0;">Instructions de paiement</h3>
                            <p style="font-size: 0.875rem; margin: 0.25rem 0;"><strong>Date limite de paiement : ${formatDate(invoice.dueDate)}</strong></p>
                            <p style="font-size: 0.875rem; margin: 0.25rem 0;">Veuillez régler par virement bancaire sur le compte suivant :</p>
                            <p style="font-size: 0.875rem; margin: 0.25rem 0; line-height: 1.5;">
                               <strong>Banque :</strong> ${settings.bankName}<br>
                               <strong>IBAN :</strong> ${settings.iban}<br>
                               <strong>BIC :</strong> ${settings.bic}
                            </p>
                            ${paymentLinkHTML}
                        </div>
                    </main>
                    <footer>
                       <p style="margin: 0 0 1rem 0;">Merci pour votre confiance.</p>
                       <p style="line-height: 1.5;">${settings.defaultFooterText.replace(/\n/g, '<br>')}</p>
                    </footer>
                </div>
                <div class="no-print" style="padding: 20px; text-align: center;">
                    <button onclick="window.print()" style="background-color: #111827; color: white; padding: 10px 24px; border: none; border-radius: 6px; cursor: pointer; font-size: 16px; margin-right: 10px;">Imprimer / PDF</button>
                    <button onclick="window.close()" style="background: transparent; border: 1px solid #d1d5db; color: #374151; padding: 10px 24px; border-radius: 6px; cursor: pointer; font-size: 16px;">Fermer</button>
                </div>
            </body>
            </html>
        `;
    };

    const generateQuoteHTML = (quote: Quote, client: Client, settings: AppSettings): string => {
        const { subtotal, totalTax, discount, netToPay, acompte } = calculateTotals(quote);
        
        const isSoleProprietorshipLike = settings.legalStatus.includes('Entreprise Individuelle') || settings.legalStatus.includes('Micro-entreprise') || settings.legalStatus.includes('EIRL');
        
        const logoHTML = settings.logoUrl 
            ? `<img src="${settings.logoUrl}" alt="Logo" style="max-height: 80px; max-width: 200px;">` 
            : `<h2 style="font-size: 1.5rem; font-weight: 700; color: #111827; margin: 0;">${settings.companyName}</h2>`;

        const emitterBlock = isSoleProprietorshipLike
            ? `<p style="font-weight: 700; font-size: 1rem; margin: 0;">${settings.companyOwnerFirstName} ${settings.companyOwnerLastName}</p>
               ${settings.companyName ? `<p style="font-size: 0.8rem; margin: 2px 0 8px 0; color: #4b5563;"><em>(Nom commercial: ${settings.companyName})</em></p>` : '<div style="height: 8px;"></div>'}
               <p style="font-size: 0.875rem; margin: 2px 0; line-height: 1.4;">${settings.companyAddress.replace(/\n/g, '<br>')}</p>
               <p style="font-size: 0.75rem; margin-top: 8px; color: #6b7280;">${settings.legalInfo}</p>
              `
            : `<p style="font-weight: 700; font-size: 1rem; margin: 0 0 4px 0;">${settings.companyName}</p>
               <p style="font-size: 0.8rem; color: #4b5563; margin: 0 0 8px 0;">${settings.legalStatus}</p>
               <p style="font-size: 0.875rem; margin: 2px 0; line-height: 1.4;">${settings.companyAddress.replace(/\n/g, '<br>')}</p>
               <p style="font-size: 0.75rem; margin-top: 8px; color: #6b7280;">${settings.legalInfo}</p>
              `;

        const lineItemsHTML = quote.lineItems.map(item => {
            const lineTotal = (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0);
            return `
                <tr style="border-bottom: 1px solid #e5e7eb;">
                    <td style="padding: 10px 0; text-align: left;">${item.description}</td>
                    <td style="padding: 10px 0; text-align: right;">${formatCurrency(Number(item.unitPrice))}</td>
                    <td style="padding: 10px 0; text-align: center;">${item.quantity}</td>
                    <td style="padding: 10px 0; text-align: right;">${formatCurrency(lineTotal)}</td>
                </tr>
            `;
        }).join('');

        return `
            <!DOCTYPE html>
            <html lang="fr">
            <head>
                <meta charset="UTF-8">
                <title>Devis ${quote.quoteNumber}</title>
                 <link rel="preconnect" href="https://fonts.googleapis.com">
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
                <style>
                    * { box-sizing: border-box; }
                    body { font-family: 'Inter', sans-serif; background-color: #f9fafb; margin: 0; padding: 1rem; color: #374151; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
                    .invoice-container { max-width: 800px; margin: 2rem auto; background: white; border: 1px solid #e5e7eb; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -2px rgba(0,0,0,0.1); }
                    .invoice-content { padding: 3rem; }
                    .info-label { color: #6b7280; font-size: 0.8rem; margin-bottom: 2px; }
                    .info-data { font-weight: 500; }
                    table { width: 100%; border-collapse: collapse; margin: 2rem 0; }
                    table th { padding: 10px 0; text-align: left; font-weight: 600; font-size: 0.8rem; letter-spacing: 0.5px; text-transform: uppercase; color: #111827; border-bottom: 2px solid ${settings.accentColor}; }
                    table td { font-size: 0.9rem; }
                    .total-summary-label { color: #4b5563; }
                    .total-summary-value { font-weight: 600; }
                    .net-payable { background-color: ${settings.accentColor}1A; border: 1px solid ${settings.accentColor}; padding: 1rem; margin-top: 1rem; border-radius: 8px; }
                    .net-payable .label { font-weight: 700; font-size: 1.1rem; color: #111827; }
                    .net-payable .value { font-weight: 700; font-size: 1.25rem; color: ${settings.accentColor}; }
                    footer { padding: 2rem 3rem; border-top: 1px solid #e5e7eb; font-size: 0.8rem; color: #6b7280; }
                    @media print { body { background-color: white; padding: 0; margin: 0; } .invoice-container { margin: 0; box-shadow: none; border: none; width: 100%; } .no-print { display: none !important; } @page { size: A4; margin: 0; } body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
                </style>
            </head>
            <body>
                <div class="invoice-container">
                    <main class="invoice-content">
                         <header style="display: flex; justify-content: space-between; align-items: flex-start; padding-bottom: 2rem; border-bottom: 1px solid #e5e7eb;">
                            <div style="flex: 1;">${logoHTML}</div>
                            <div style="text-align: right;">
                                <h1 style="font-size: 2.5rem; font-weight: 700; color: ${settings.accentColor}; margin: 0;">DEVIS</h1>
                                <p class="info-data" style="margin: 0;">${quote.quoteNumber}</p>
                            </div>
                        </header>
                         <section style="display: flex; justify-content: space-between; margin-top: 2rem;">
                            <div style="width: 48%;">
                                <p class="info-label" style="text-transform: uppercase; font-weight: 600;">DE</p>
                                ${emitterBlock}
                            </div>
                            <div style="width: 48%;">
                                <div style="margin-bottom: 1.5rem;">
                                    <p class="info-label">Date d'émission</p>
                                    <p class="info-data">${formatDate(quote.issueDate)}</p>
                                </div>
                                <div>
                                    <p class="info-label" style="text-transform: uppercase; font-weight: 600;">POUR</p>
                                    <p class="info-data" style="font-size: 1rem; font-weight: 600; margin-bottom: 4px;">${client.name}</p>
                                    <p style="font-size: 0.875rem; margin: 2px 0; line-height: 1.4;">${client.address.replace(/\n/g, '<br>')}</p>
                                    <p style="font-size: 0.875rem; margin: 2px 0;">${client.email}</p>
                                </div>
                            </div>
                        </section>
                        <table>
                            <thead>
                                <tr>
                                    <th>Description</th>
                                    <th style="text-align: right;">Prix unitaire</th>
                                    <th style="text-align: center;">Quantité</th>
                                    <th style="text-align: right;">Total</th>
                                </tr>
                            </thead>
                            <tbody>${lineItemsHTML}</tbody>
                        </table>
                        <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                             <div style="width: 50%;">
                               <h3 style="font-size: 1rem; font-weight: 600; margin: 0 0 1rem 0;">Validité de l'offre</h3>
                               <p style="font-size: 0.875rem; margin: 0.25rem 0;">Ce devis est valable jusqu'au <strong>${formatDate(quote.expiryDate)}</strong>.</p>
                            </div>
                            <div style="width: 50%; max-width: 350px; font-size: 0.9rem;">
                                <div style="display: flex; justify-content: space-between; padding: 6px 0;">
                                    <span class="total-summary-label">TOTAL HT</span><span class="total-summary-value">${formatCurrency(subtotal)}</span>
                                </div>
                                <div style="display: flex; justify-content: space-between; padding: 6px 0;">
                                    <span class="total-summary-label">TVA</span><span class="total-summary-value">${formatCurrency(totalTax)}</span>
                                </div>
                                 ${discount > 0 ? `<div style="display: flex; justify-content: space-between; padding: 6px 0;">
                                    <span class="total-summary-label">REMISE</span><span class="total-summary-value">-${formatCurrency(discount)}</span>
                                </div>` : ''}
                                 ${acompte > 0 ? `<div style="display: flex; justify-content: space-between; padding: 6px 0;">
                                    <span class="total-summary-label">ACOMPTE DEMANDÉ</span><span class="total-summary-value">${formatCurrency(acompte)}</span>
                                </div>` : ''}
                                <div class="net-payable">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <span class="label">MONTANT TOTAL</span>
                                        <span class="value">${formatCurrency(netToPay)}</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </main>
                     <footer class="invoice-footer">
                        <p style="margin: 0 0 1rem 0;">Pour toute question, n'hésitez pas à nous contacter.</p>
                        <p style="line-height: 1.5;">${settings.defaultPaymentTerms.replace(/\n/g, '<br>')}</p>
                    </footer>
                </div>
                <div class="no-print" style="padding: 20px; text-align: center;">
                    <button onclick="window.print()" style="background-color: #111827; color: white; padding: 10px 24px; border: none; border-radius: 6px; cursor: pointer; font-size: 16px; margin-right: 10px;">Imprimer / PDF</button>
                    <button onclick="window.close()" style="background: transparent; border: 1px solid #d1d5db; color: #374151; padding: 10px 24px; border-radius: 6px; cursor: pointer; font-size: 16px;">Fermer</button>
                </div>
            </body>
            </html>
        `;
    };


    const handleDownloadInvoice = (invoiceToDownload: Invoice) => {
        const client = clients.find(c => c.id === invoiceToDownload.clientId);
        if (!client) return;
        
        const invoiceHTML = generateInvoiceHTML(invoiceToDownload, client, settings);
        
        const newWindow = window.open('', '', 'width=800,height=900');
        if (newWindow) {
            newWindow.document.open();
            newWindow.document.write(invoiceHTML);
            newWindow.document.close();
        }
    };
    
    const handleSendInvoice = (invoiceToSend: Invoice) => {
        const client = clients.find(c => c.id === invoiceToSend.clientId);
        if (!client) return;
        setDocumentToSend({ doc: invoiceToSend, client: client, type: 'invoice' });
    };

    const handleDownloadQuote = (quoteToDownload: Quote) => {
        const client = clients.find(c => c.id === quoteToDownload.clientId);
        if (!client) return;
        const quoteHTML = generateQuoteHTML(quoteToDownload, client, settings);
        const newWindow = window.open('', '', 'width=800,height=900');
        if (newWindow) {
            newWindow.document.open();
            newWindow.document.write(quoteHTML);
            newWindow.document.close();
        }
    };
    
    const handleSendQuote = (quoteToSend: Quote) => {
        const client = clients.find(c => c.id === quoteToSend.clientId);
        if (!client) return;
        setDocumentToSend({ doc: quoteToSend, client: client, type: 'quote' });
    };

    const handleConfirmSend = (subject: string, body: string) => {
        if (!documentToSend) return;

        const { doc, client, type } = documentToSend;

        if (type === 'invoice') {
            const invoice = doc as Invoice;
            // In a real app, this is where you would call an email API
            console.log(`Sending invoice ${invoice.invoiceNumber} to ${client.email}`);
            console.log(`Subject: ${subject}`);
            console.log(`Body: ${body}`);

            if (invoice.status === InvoiceStatus.Draft) {
                const updatedInvoice = { ...invoice, status: InvoiceStatus.Sent };
                setInvoices(invoices.map(inv => inv.id === updatedInvoice.id ? updatedInvoice : inv));
            }
            alert(`La facture ${invoice.invoiceNumber} a été envoyée (simulé) à ${client.email}.`);
        } else {
            const quote = doc as Quote;
            // In a real app, this is where you would call an email API
            console.log(`Sending quote ${quote.quoteNumber} to ${client.email}`);
            console.log(`Subject: ${subject}`);
            console.log(`Body: ${body}`);

            if (quote.status === QuoteStatus.Draft) {
                const updatedQuote = { ...quote, status: QuoteStatus.Sent };
                setQuotes(quotes.map(q => q.id === updatedQuote.id ? updatedQuote : q));
            }
            alert(`Le devis ${quote.quoteNumber} a été envoyé (simulé) à ${client.email}.`);
        }

        setDocumentToSend(null);
    };
    
    const handleConvertToInvoice = (quote: Quote) => {
        const newDraftInvoice = {
            clientId: quote.clientId,
            issueDate: new Date().toISOString().split('T')[0],
            dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            lineItems: quote.lineItems.map(item => ({ ...item, id: `li_${Date.now()}_${Math.random()}`})),
            status: InvoiceStatus.Draft,
            discount: quote.discount,
            acompte: quote.acompte,
        };
        handleOpenEditor(newDraftInvoice as Invoice);
        setCurrentPage(Page.Invoices);
    };

    const renderPage = () => {
        // When switching pages, if we are viewing a client, reset that state
        if (viewingClient && currentPage !== Page.Clients) {
            setViewingClient(null);
        }

        switch (currentPage) {
            case Page.Dashboard:
                return <Dashboard 
                            invoices={invoices} 
                            quotes={quotes} 
                            clients={clients} 
                            settings={settings}
                            onEditInvoice={handleOpenEditor}
                            onEditQuote={handleOpenQuoteEditor}
                       />;
            case Page.Invoices:
                return <InvoiceList 
                            invoices={invoices} 
                            clients={clients} 
                            onEditInvoice={handleOpenEditor} 
                            onCreateInvoice={() => handleOpenEditor(null)} 
                            onDownloadInvoice={handleDownloadInvoice}
                            onSendInvoice={handleSendInvoice}
                        />;
            case Page.Quotes:
                return <QuoteList
                            quotes={quotes}
                            clients={clients}
                            onEditQuote={handleOpenQuoteEditor}
                            onCreateQuote={() => handleOpenQuoteEditor(null)}
                            onDownloadQuote={handleDownloadQuote}
                            onSendQuote={handleSendQuote}
                            onConvertToInvoice={handleConvertToInvoice}
                        />;
            case Page.Clients:
                 if (viewingClient) {
                    return <ClientDetail 
                                client={viewingClient}
                                invoices={invoices.filter(inv => inv.clientId === viewingClient.id)}
                                quotes={quotes.filter(q => q.clientId === viewingClient.id)}
                                onBack={() => setViewingClient(null)}
                                onEditClient={handleOpenClientEditor}
                                calculateTotal={calculateTotals}
                                onEditInvoice={handleOpenEditor}
                                onEditQuote={handleOpenQuoteEditor}
                           />;
                }
                return <ClientList 
                            clients={clients} 
                            invoices={invoices}
                            quotes={quotes}
                            onViewClient={handleViewClient}
                            onEditClient={handleOpenClientEditor} 
                            onCreateClient={() => handleOpenClientEditor(null)} 
                            onImportClients={handleImportClients}
                            onDeleteClient={handleDeleteClient}
                            onCreateInvoiceForClient={handleCreateInvoiceForClient}
                            onCreateQuoteForClient={handleCreateQuoteForClient}
                       />;
            case Page.Reports:
                return <Reports invoices={invoices} clients={clients} calculateTotals={calculateTotals} onEditInvoice={handleOpenEditor} />;
            case Page.Settings:
                return <Settings settings={settings} onSave={handleSaveSettings} />;
            default:
                return <Dashboard invoices={invoices} quotes={quotes} clients={clients} settings={settings} onEditInvoice={handleOpenEditor} onEditQuote={handleOpenQuoteEditor} />;
        }
    };
    
    if (!isLoggedIn) {
        return <LoginPage onLogin={handleLogin} />;
    }

    return (
        <div className="bg-background min-h-screen font-sans text-foreground">
            <div className="flex">
                <Sidebar currentPage={currentPage} setCurrentPage={setCurrentPage} isMobileMenuOpen={isMobileMenuOpen} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <div className="flex-1 transition-all duration-300 md:ml-64 flex flex-col">
                   <Header 
                        onMenuClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} 
                        clients={clients}
                        invoices={invoices}
                        onSearchSelect={handleSearchSelect}
                        settings={settings}
                        onLogout={handleLogout}
                    />
                    <main className="flex-1">
                        <div className="p-4 md:p-8">
                            {renderPage()}
                        </div>
                    </main>
                </div>
            </div>
            {isEditorOpen && (
                <InvoiceEditor
                    invoice={editingInvoice}
                    clients={clients}
                    settings={settings}
                    onClose={() => setIsEditorOpen(false)}
                    onSave={handleSaveInvoice}
                />
            )}
            {isQuoteEditorOpen && (
                 <QuoteEditor
                    quote={editingQuote}
                    clients={clients}
                    settings={settings}
                    onClose={() => setIsQuoteEditorOpen(false)}
                    onSave={handleSaveQuote}
                />
            )}
            {isClientEditorOpen && (
                <ClientEditor
                    client={editingClient}
                    onClose={() => setIsClientEditorOpen(false)}
                    onSave={handleSaveClient}
                />
            )}
            {documentToSend && (
                <SendModal
                    documentInfo={documentToSend}
                    settings={settings}
                    onClose={() => setDocumentToSend(null)}
                    onConfirm={handleConfirmSend}
                />
            )}
        </div>
    );
};

export default App;