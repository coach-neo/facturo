import { useState, useEffect } from 'react';
import { Client, Invoice, Quote, Settings, InvoiceStatus, QuoteStatus } from '../types';

const initialClients: Client[] = [
    { id: 'cli_1', name: 'Tech Solutions Inc.', email: 'contact@techsolutions.com', address: '123 Tech Street, 94105 San Francisco', phone: '01 23 45 67 89', notes: 'Client fidèle, préfère la communication par email.' },
    { id: 'cli_2', name: 'Innovate Corp', email: 'hello@innovatecorp.io', address: '456 Innovation Ave, 75002 Paris', phone: '09 87 65 43 21', notes: 'Nouveau prospect, intéressé par un contrat de maintenance.' },
    { id: 'cli_3', name: 'Design Studio', email: 'studio@design.com', address: '789 Creative Blvd, 10012 New York', phone: '06 11 22 33 44', notes: '' },
];

const initialInvoices: Invoice[] = [
    { 
        id: 'inv_1', 
        invoiceNumber: 'FACT-2024-001', 
        clientId: 'cli_1', 
        issueDate: '2024-07-15', 
        dueDate: '2024-08-14', 
        status: InvoiceStatus.Paid, 
        discount: 0, 
        acompte: 1000,
        lineItems: [
            { id: 'li_1', description: 'Développement site web', quantity: 1, unitPrice: 5000, taxRate: 0.20 },
            { id: 'li_2', description: 'Hébergement (Annuel)', quantity: 1, unitPrice: 300, taxRate: 0.20 },
        ],
        paymentDate: '2024-07-25',
        paymentMethod: 'Virement bancaire'
    },
    { 
        id: 'inv_2', 
        invoiceNumber: 'FACT-2024-002', 
        clientId: 'cli_2', 
        issueDate: '2024-07-20', 
        dueDate: '2024-08-19', 
        status: InvoiceStatus.Sent, 
        discount: 100, 
        acompte: 0,
        lineItems: [
            { id: 'li_3', description: 'Design Logo & Branding', quantity: 1, unitPrice: 2500, taxRate: 0.20 },
        ]
    },
    { 
        id: 'inv_3', 
        invoiceNumber: 'FACT-2024-003', 
        clientId: 'cli_3', 
        issueDate: '2024-06-25', 
        dueDate: '2024-07-25', 
        status: InvoiceStatus.Overdue, 
        discount: 0, 
        acompte: 0,
        lineItems: [
            { id: 'li_4', description: 'Consulting UX/UI (5h)', quantity: 5, unitPrice: 150, taxRate: 0.20 },
        ]
    },
    { 
        id: 'inv_4', 
        invoiceNumber: 'FACT-2024-004', 
        clientId: 'cli_1', 
        issueDate: '2024-07-28', 
        dueDate: '2024-08-27', 
        status: InvoiceStatus.Draft, 
        discount: 0, 
        acompte: 0,
        lineItems: [
            { id: 'li_5', description: 'Maintenance', quantity: 1, unitPrice: 500, taxRate: 0.20 },
        ]
    },
];

const initialQuotes: Quote[] = [
    { id: 'quo_1', quoteNumber: 'DEV-2024-001', clientId: 'cli_2', issueDate: '2024-07-10', expiryDate: '2024-08-09', status: QuoteStatus.Accepted, discount: 0, acompte: 500, lineItems: [
        { id: 'li_6', description: 'Refonte graphique', quantity: 1, unitPrice: 3000, taxRate: 0.20 },
    ]},
    { id: 'quo_2', quoteNumber: 'DEV-2024-002', clientId: 'cli_3', issueDate: '2024-07-22', expiryDate: '2024-08-21', status: QuoteStatus.Sent, discount: 50, acompte: 0, lineItems: [
        { id: 'li_7', description: 'Campagne publicitaire', quantity: 1, unitPrice: 1500, taxRate: 0.20 },
    ]},
];

const initialSettings: Settings = {
    companyName: 'Votre Entreprise',
    companyAddress: '1 rue de la Paix, 75001 Paris, France',
    logoUrl: null,
    accentColor: '#3B82F6',
    legalInfo: 'SIRET: 123 456 789 00012 - TVA Intracommunautaire: FR123456789',
    legalStatus: 'Entreprise Individuelle (EI)',
    isSoleProprietorship: true,
    companyOwnerFirstName: 'Loïc',
    companyOwnerLastName: 'Dupont',
    bankName: 'Votre Banque SA',
    iban: 'FR76 3000 6000 0112 3456 7890 189',
    bic: 'SOGEFRPP',
    paymentLink: '',
    invoicePrefix: 'FACT-',
    nextInvoiceNumber: 5,
    quotePrefix: 'DEV-',
    nextQuoteNumber: 3,
    defaultTaxRate: 0.20,
    defaultPaymentTerms: 'Paiement à 30 jours net.',
    defaultFooterText: 'Taux des pénalités de retard: 10% par jour de retard.\nIndemnité forfaitaire pour frais de recouvrement de 40 €.\nConditions générales de vente disponibles sur le site.',
};

const LOCAL_STORAGE_KEYS = {
    CLIENTS: 'neofact-clients',
    INVOICES: 'neofact-invoices',
    QUOTES: 'neofact-quotes',
    SETTINGS: 'neofact-settings',
};

const loadFromStorage = <T,>(key: string, fallback: T): T => {
    try {
        const stored = localStorage.getItem(key);
        return stored ? JSON.parse(stored) : fallback;
    } catch (error) {
        console.error(`Error loading ${key} from localStorage`, error);
        return fallback;
    }
};


export const useMockData = () => {
    const [clients, setClients] = useState<Client[]>(() => loadFromStorage(LOCAL_STORAGE_KEYS.CLIENTS, initialClients));
    const [invoices, setInvoices] = useState<Invoice[]>(() => loadFromStorage(LOCAL_STORAGE_KEYS.INVOICES, initialInvoices));
    const [quotes, setQuotes] = useState<Quote[]>(() => loadFromStorage(LOCAL_STORAGE_KEYS.QUOTES, initialQuotes));
    const [settings, setSettings] = useState<Settings>(() => loadFromStorage(LOCAL_STORAGE_KEYS.SETTINGS, initialSettings));

    useEffect(() => {
        localStorage.setItem(LOCAL_STORAGE_KEYS.CLIENTS, JSON.stringify(clients));
    }, [clients]);

    useEffect(() => {
        localStorage.setItem(LOCAL_STORAGE_KEYS.INVOICES, JSON.stringify(invoices));
    }, [invoices]);
    
    useEffect(() => {
        localStorage.setItem(LOCAL_STORAGE_KEYS.QUOTES, JSON.stringify(quotes));
    }, [quotes]);

    useEffect(() => {
        localStorage.setItem(LOCAL_STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    }, [settings]);

    return {
        clients, setClients,
        invoices, setInvoices,
        quotes, setQuotes,
        settings, setSettings
    };
};